![PHBSockets](https://user-images.githubusercontent.com/34753501/137428948-9dfc2552-f6df-477b-9bea-7cc07894c2df.png)

# How to install plugin
Before using the plugin, you must insert a record in the emulator_settings table.
- Key: phbplugin.install.language
- EN for install english texts or PT for install portuguese texts.

# How to install Websocket Client
coming soon...

# Support 
In case of problems, please contact me directly.

- [Discord Server](https://discord.gg/GZY3EQ3hEH)
- [My Website](https://phb.services/)
- [WhatsApp](https://wa.me/5521998149241)

# Changelogs
- 14/10/21 - Now you can install with texts in Portuguese and English.


