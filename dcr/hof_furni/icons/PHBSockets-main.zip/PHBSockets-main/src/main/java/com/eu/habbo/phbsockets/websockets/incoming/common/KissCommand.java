package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.permissions.PermissionSetting;
import com.eu.habbo.habbohotel.rooms.RoomChatMessageBubbles;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class KissCommand extends IncomingWebMessage<KissCommand.JSONBeijarCommand> {

    public KissCommand() {
        super(JSONBeijarCommand.class);
    }

    @Override
    public void handle(WebSocketClient gameClient, JSONBeijarCommand message) throws InterruptedException {

        Habbo habbo = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getHabbo(message.username);

        if (habbo != null) {

            /// Sistema de desativar comandos no quarto
            if (Emulator.getConfig().getInt("phbplugin.blockcmd.enabled") == 1) {
                if (gameClient.getHabbo().getHabboInfo().getRank().getPermissions().get("acc_override_blockcmd").setting == PermissionSetting.DISALLOWED) {
                    try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
                         PreparedStatement statement = connection.prepareStatement("SELECT COUNT(id) as total FROM phbplugin_roomblockcmd WHERE room_id = ? AND comando = ?;")) {
                        statement.setInt(1, gameClient.getHabbo().getHabboInfo().getCurrentRoom().getId());
                        statement.setString(2, "beijar");
                        try (ResultSet set = statement.executeQuery()) {
                            if (set.next()) {
                                Integer total = set.getInt("total");
                                if (total >= 1) {
                                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_blockcmd.command.error"));
                                    return;
                                }
                            }
                        }
                    } catch (SQLException e) {
                        Emulator.getLogging().logSQLException(e);
                    }
                }
            }

            /// Cooldown
            Integer timestamp = Emulator.getIntUnixTimestamp();
            Integer last_cmd = 0;
            // Verifica se usuário pode executar comando
            if(gameClient.getHabbo().getHabboStats().cache.contains("last_kiss")) {
                last_cmd = Integer.parseInt(gameClient.getHabbo().getHabboStats().cache.get("last_kiss").toString());
                Integer cooldown = Integer.parseInt(Emulator.getConfig().getValue("phbsockets.kiss.cooldown"));
                ///Bypass
                if (gameClient.getHabbo().getHabboInfo().getRank().getId() >= Integer.valueOf(Emulator.getConfig().getValue("phbsockets.rank.cooldown.bypass")))
                    last_cmd = 0;
                if (timestamp - last_cmd < cooldown) {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.cooldown.error").replace("%time%", String.valueOf(((last_cmd + cooldown) - timestamp))));
                    return;
                }
            }
            gameClient.getHabbo().getHabboStats().cache.put("last_kiss", timestamp);

            if (habbo != gameClient.getHabbo()) {
                if (habbo.getRoomUnit().getCurrentLocation().distance(gameClient.getHabbo().getRoomUnit().getCurrentLocation()) <= 1.5) {

                    habbo.getRoomUnit().lookAtPoint(gameClient.getHabbo().getRoomUnit().getCurrentLocation());
                    gameClient.getHabbo().getRoomUnit().lookAtPoint(habbo.getRoomUnit().getCurrentLocation());
                    gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.texts.cmd_kiss.kiss").replace("%username%", habbo.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                }
                else {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.texts.cmd_beijar.error"));
                }
            }
        }
    }

    static class JSONBeijarCommand {
        String username;
    }
}
