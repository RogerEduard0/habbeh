package com.eu.habbo.phbsockets.eventloader;

import com.eu.habbo.Emulator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class PluginDatabaseRegister {

    private static final Logger LOGGER = LoggerFactory.getLogger(PluginDatabaseRegister.class);

    public static void checkPluginDB() {
        registerUserEnum("event_alert", "'true', 'false'", "true");
        registerUserEnum("sex_enabled", "'true', 'false'", "true");
        CreateYoutubeTvTable();
    }

    private static boolean registerUserEnum(String name, String options, String defaultValue)
    {
        try (Connection connection = Emulator.getDatabase().getDataSource().getConnection())
        {
            try (PreparedStatement statement = connection.prepareStatement("ALTER TABLE  `users` ADD  `" + name +"` ENUM(  " + options + " ) NOT NULL DEFAULT  '" + defaultValue + "'"))
            {
                statement.execute();
                return true;
            }
        }
        catch (SQLException e){
        }
        return false;
    }

    private static boolean CreateYoutubeTvTable() {
        try (Connection connection = Emulator.getDatabase().getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement("CREATE TABLE `phbplugin_youtubetv` (`id` INT(11) NOT NULL AUTO_INCREMENT,`user_id` INT(11) NULL DEFAULT NULL,`video_id` VARCHAR(100) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',`video_title` VARCHAR(150) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',`video_channel` VARCHAR(100) NULL DEFAULT NULL COLLATE 'latin1_swedish_ci',PRIMARY KEY (`id`) USING BTREE)COLLATE='latin1_swedish_ci'ENGINE=InnoDB AUTO_INCREMENT=0;")) {
                statement.execute();
                return true;
            }
        } catch (SQLException e) {
        }
        return false;
    }

}