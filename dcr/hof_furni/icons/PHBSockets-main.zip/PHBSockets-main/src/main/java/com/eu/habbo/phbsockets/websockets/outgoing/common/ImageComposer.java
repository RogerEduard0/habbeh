package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class ImageComposer extends OutgoingWebMessage {
    public ImageComposer(String url) {
        super("image");
        this.data.add("url", new JsonPrimitive(url));
    }
}