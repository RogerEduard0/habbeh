package com.eu.habbo.phbsockets.eventloader;

import com.eu.habbo.Emulator;
import com.eu.habbo.phbsockets.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoadTextsEN {
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    public static void loadTexts() {
        try {
            LOGGER.info("[PHBSockets] - Loading texts...");

            Emulator.getTexts().register("commands.cmd_eventalert.keys", "eha;evento");
            Emulator.getTexts().register("commands.description.cmd_eventalert", ":eha - Event Alert");
            Emulator.getTexts().register("commands.text.cmd_eventalert.disabledtext", "A new event is rolling, use the command :eventsoff to receive alerts.");

            Emulator.getTexts().register("commands.cmd_roomvideo.keys", "roomvideo");
            Emulator.getTexts().register("commands.description.cmd_roomvideo", ":roomvideo - Opens a video popup in the room");
            Emulator.getTexts().register("commands.text.cmd_roomvideo.error", "You have not entered a valid link (Youtube, Twitch, Facebook, Xvideos or PornHUB)");
            Emulator.getTexts().register("commands.text.cmd_roomvideo.owner", "You cannot use this command here.");

            Emulator.getTexts().register("commands.cmd_hotelvideo.keys", "hotelvideo");
            Emulator.getTexts().register("commands.description.cmd_hotelvideo", ":hotelvideo link");

            Emulator.getTexts().register("commands.cmd_disablealertevent.keys", "eventsoff");
            Emulator.getTexts().register("commands.description.cmd_disablealertevent", ":eventsoff");
            Emulator.getTexts().register("commands.text.cmd_disablealertevent.disabled", "You will now no longer receive event alerts!");
            Emulator.getTexts().register("commands.text.cmd_disablealertevent.enabled", "You will now return to receiving event alerts!");

            Emulator.getTexts().register("commands.description.cmd_furnidata", ":furnidata");
            Emulator.getTexts().register("commands.cmd_furnidata.keys", "furnidata");
            Emulator.getTexts().register("commands.cmd_furnidata.on", "Successfully turned furnidata on!");
            Emulator.getTexts().register("commands.cmd_furnidata.off", "Successfully turned furnidata off!");

            Emulator.getTexts().register("phbsockets.mention.needy", "You can't mention yourself, are you needy?");
            Emulator.getTexts().register("phbsockets.mention.invaliduser", "The user you tried to mention is not online or does not exist.");
            Emulator.getTexts().register("phbsockets.mention.reply", "The next message sent will be addressed to user %username%.");
            Emulator.getTexts().register("phbsockets.mention.replied", "Your message has been sent to %username%.");

            Emulator.getTexts().register("commands.cmd_roomimage.keys", "roomimage");
            Emulator.getTexts().register("commands.description.cmd_roomimage", ":roomimage - Opens an image popup in the room");
            Emulator.getTexts().register("commands.text.cmd_roomimage.url", "You have not entered a valid image url.");
            Emulator.getTexts().register("commands.text.cmd_roomimage.owner", "You cannot use this command here.");

            Emulator.getTexts().register("commands.cmd_hotelimage.keys", "hotelimage");
            Emulator.getTexts().register("commands.description.cmd_hotelimage", ":hotelimage - Opens an image popup in the entire hotel");

            Emulator.getTexts().register("commands.cmd_edititem.keys", "edititem");
            Emulator.getTexts().register("commands.description.cmd_edititem", ":edititem - Edit item");
            Emulator.getTexts().register("commands.text.cmd_edititem.invalidfurni", "Item %id% does not exist!");
            Emulator.getTexts().register("commands.text.cmd_edititem.invalidparam", "Invalid parameter!");
            Emulator.getTexts().register("commands.text.cmd_edititem.error", "There was an error running the command, you may have set an invalid value.");
            Emulator.getTexts().register("commands.text.cmd_edititem.success", "The %param% parameter of item %id% has been set to %value%.");
            Emulator.getTexts().register("commands.text.cmd_edititem.success.ws", "You have just edited the %id% item.");
            Emulator.getTexts().register("commands.text.cmd_edititem.disabled", "Edit item disabled.");
            Emulator.getTexts().register("commands.text.cmd_edititem.enabled", "Double click on a mobi to open the edit menu.");
            Emulator.getTexts().register("commands.text.cmd_edititem.example1", "Example: :edititem 4768 allow_sit 1");
            Emulator.getTexts().register("commands.text.cmd_edititem.example2", "You can also use :editaritem id to open the edit menu.");
            Emulator.getTexts().register("commands.text.cmd_edititem.example3", "If you want to edit without the menu, use :edititem id parameter value, example: :edititem 1 allow_sit 1");

            Emulator.getTexts().register("phbsockets.youtube.api.error", "Error with Youtube API, please try again later.");
            Emulator.getTexts().register("phbsockets.youtube.api.config", "YouTube API has not been configured, configure in emulator_settings.");

            Emulator.getTexts().register("commands.cmd_youtube.keys", "youtube");
            Emulator.getTexts().register("commands.description.cmd_youtube", ":youtube - Search a Youtube video");
            Emulator.getTexts().register("commands.texts.cmd_youtube.error", "You have not entered the name of the video you would like to play.");
            Emulator.getTexts().register("commands.texts.cmd_youtube.success", "Playing %title% video in the room.");

            Emulator.getTexts().register("commands.cmd_addvideo_youtubetv.keys", "addvideo");
            Emulator.getTexts().register("commands.description.cmd_addvideo_youtubetv", ":addvideo - Add video to your youtube tv playlist");
            Emulator.getTexts().register("commands.cmd_addvideo_youtubetv.error", "You have not entered the name of the video you would like to add to your tv.");
            Emulator.getTexts().register("commands.cmd_addvideo_youtubetv.success", "The video %title% from channel %channel% has been added to your playlist.");

            Emulator.getTexts().register("commands.cmd_manage_youtubetv.keys", "managetv");
            Emulator.getTexts().register("commands.description.cmd_manage_youtubetv", ":managetv - Manage your Youtube Tv Playlist");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.list", "list");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.remove", "remove");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.error", "You must type :managetv list or :managetv remove id.");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.listing", "Listing videos in your playlist:");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.howremove", "To remove a video use :managetv remove id");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.removed", "The video has been removed from your playlist.");

            Emulator.getTexts().register("commands.cmd_youtubemusic.keys", "roommusic;musica;music;youtubemusic;musicayoutube");
            Emulator.getTexts().register("commands.description.cmd_youtubemusic", ":roommusic");
            Emulator.getTexts().register("commands.text.cmd_youtubemusic.success", "Opening %title% song in the room.");

            Emulator.getTexts().register("commands.cmd_roomiframe.keys", "roomiframe");
            Emulator.getTexts().register("commands.description.cmd_roomiframe", ":roomiframe");
            Emulator.getTexts().register("commands.text.cmd_roomiframe", ":roomiframe");
            Emulator.getTexts().register("commands.text.cmd_roomiframe.error", "You must use :roomiframe url");
            Emulator.getTexts().register("commands.text.cmd_roomiframe.owner", "You are not allowed to use the command in this room.");

            Emulator.getTexts().register("commands.cmd_hoteliframe.keys", "hoteliframe");
            Emulator.getTexts().register("commands.text.cmd_hoteliframe", ":hoteliframe - Open an iframe popup");
            Emulator.getTexts().register("commands.text.cmd_hoteliframe.error", "You must use :hoteliframe url");

            Emulator.getTexts().register("commands.cmd_disablesex.keys", "disablesex");
            Emulator.getTexts().register("commands.description.cmd_disablesex", ":disablesex - Disable sex command");
            Emulator.getTexts().register("commands.text.cmd_disablesex.disabled", "Now you can't have sex anymore!");
            Emulator.getTexts().register("commands.text.cmd_disablesex.enabled", "Now you will be able to get laid again!");

            Emulator.getTexts().register("phbsockets.cooldown.error", "You need to wait %time% seconds to use this command again.");

            Emulator.getTexts().register("commands.cmd_sex.keys", "sexo;transar;sex");
            Emulator.getTexts().register("commands.description.cmd_sex", ":sexo - Has sex with a user");
            Emulator.getTexts().register("commands.text.cmd_sex.my.disabled", "You cannot use this command if you have sex disabled! use the command :disablesex to enable sex.");
            Emulator.getTexts().register("commands.text.cmd_sex.user.disabled", "User has sex disabled.");
            Emulator.getTexts().register("commands.text.cmd_sex.distance", "This user is too far away, get closer and try again.");
            Emulator.getTexts().register("commands.text.cmd_sex.needy", "You can't have sex with yourself, are you needy?");
            Emulator.getTexts().register("commands.text.cmd_sex.error.user", "User not found.");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk1", "*Botando com força no buraco do %user%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk2", "*Empurro com força no %user%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk3", "*Ohaaaaaaaaaaaaaar*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk4", "*Que pau de jegue %user2%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk5", "*Não enfia tudo, tá doendo*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk6", "*Aiiii pai paraaaaaa*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk7", "*Não bota tudõo que eu piro aloka*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk8", "*Eu to pro crime hoje*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk9", "**Ain que pauzinho gostoso*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk10", "*Aahhhhhhhhhhhhhhr*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk11", "*Mete gostosinho no meu cuzinho vai dlç*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk12", "*Gozei litros dentro do %user%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk1", "*Colando velcro com a %user%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk2", "*Puxa delicadamente para não raspar os pelos da %user%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk3", "*nheeeeeeeeeeeec*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk4", "*ohaaaaaaaaaaaaaaaaar*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk5", "*Esfrega vai, esfregaa*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk6", "*Esfrega mais rápido*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk7", "*Faz aquela posição que eu piro*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk8", "*Sentindo prazer*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk9", "*Corta as unhas e faz o dj em mim amor*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk1", "*Botando na xavasca da %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk2", "*AAAAAAIN QUE DELÍÍÍCIA, FODE ESSA BUCETAAA!*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk3", "*Empurrando com força na %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk4", "*Ain pai paraaa, vai devagar, seu gostoso!*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk5", "*Empurra rapidamente o cano do fuzil*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk6", "*Retirando a jeba da prexeca da %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk7", "*Que gostoso seu pirocudo, fode mais, vai*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk1", "*Seduzindo o %m%, VEM E EMPURRA TUDO NA MINHA XOXOTINHA*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk2", "*Botando na xavasca da %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk3", "*AAAAAAIN QUE DELÍÍÍCIA, FODE ESSA BUCETAAA!*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk4", "*Empurrando com força na %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk5", "*Ain pai paraaa, vai devagar, seu gostoso!*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk6", "*Empurra rapidamente o cano do fuzil*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk7", "*Retirando a jeba da prexeca da %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk8", "*Que gostoso seu pirocudo, fode mais, vai*");

            Emulator.getTexts().register("commands.description.cmd_slime", ":slime <username>");
            Emulator.getTexts().register("commands.cmd_slime.keys", "slime;slimed;goop;nickelodeon");
            Emulator.getTexts().register("commands.text.cmd_slime.throws", "* Throws slime at %username%s direction *");
            Emulator.getTexts().register("commands.text.cmd_slime.missed", "* Missed %username%s face *");
            Emulator.getTexts().register("commands.text.cmd_slime.slimed", "* Gets covered in slime by %username% *");

            Emulator.getTexts().register("phbsockets.followuser.error", "You are already in this room.");

            Emulator.getTexts().register("commands.description.cmd_nuke", ":nuke <username>");
            Emulator.getTexts().register("commands.cmd_nuke.keys", "nuke;nade;grenade;explode;boom");
            Emulator.getTexts().register("commands.text.nuke.self", "You can't nuke yourself, silly!");
            Emulator.getTexts().register("commands.text.nuke.action", "* Launches nuke towards %username% *");
            Emulator.getTexts().register("commands.text.nuke.nuked", "* %username% gets obliterated *");

            Emulator.getTexts().register("commands.description.cmd_hug", ":hug <username>");
            Emulator.getTexts().register("commands.cmd_hug.keys", "hug;cuddle");
            Emulator.getTexts().register("commands.text.cmd_hug.huggedperson", "* Gets a warm hug from %hugger% *");
            Emulator.getTexts().register("commands.text.cmd_hug.hugger", "* Hugs %huggedperson% tightly *");
            Emulator.getTexts().register("commands.text.cmd_hug.tofar", "%huggedperson% is too far to hug. Get a bit closer and try again!");

            Emulator.getTexts().register("commands.cmd_coloradd.keys", "coloradd");
            Emulator.getTexts().register("commands.description.cmd_coloradd", ":coloradd - Assistance for the colorblind");

            Emulator.getTexts().register("commands.description.cmd_cataltd", ":cataltd - Update catalog and send new ltd alert.");
            Emulator.getTexts().register("commands.cmd_cataltd.keys", "cataltd");

            Emulator.getTexts().register("commands.texts.cmd_kiss.kiss", "*Kissing %username%*");

            Emulator.getTexts().register("commands.text.cmd_disablesex.enabled", "Sex enabled!");
            Emulator.getTexts().register("commands.text.cmd_disablesex.disabled", "Sex disabled!");
            Emulator.getTexts().register("commands.cmd_disablesex.keys", "disablesex;enablesex");
            Emulator.getTexts().register("commands.description.cmd_disablesex", ":disablesex - Enable/disable sex command.");
        } catch (Exception ex) {
           LOGGER.info(ex.getMessage());
        }
    }
}
