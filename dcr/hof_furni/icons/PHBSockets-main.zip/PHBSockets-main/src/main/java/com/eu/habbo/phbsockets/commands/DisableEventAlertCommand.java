package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class DisableEventAlertCommand extends Command
{
    public DisableEventAlertCommand(String permission, String[] keys)
    {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] strings) throws Exception
    {
        String eventAlert = gameClient.getHabbo().getHabboStats().cache.get("event_alert").toString();
        if(eventAlert.equals("false") || eventAlert.contains("false")) {
            gameClient.getHabbo().getHabboStats().cache.put("event_alert", "true");
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_eventosoff.enabled"));
        }
        else {
            gameClient.getHabbo().getHabboStats().cache.put("event_alert", "false");
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_eventosoff.disabled"));
        }

        /// Altera na DB
        try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
             PreparedStatement pstmt = connection.prepareStatement("UPDATE users SET event_alert = ? WHERE id = ? LIMIT 1", Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, gameClient.getHabbo().getHabboStats().cache.get("sex_enabled").toString());
            pstmt.setInt(2, gameClient.getHabbo().getHabboInfo().getId());
            pstmt.execute();
        } catch (SQLException e) {
            Emulator.getLogging().logSQLException(e);
        }

        return true;
    }
}

