package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class EntryRoomComposer extends OutgoingWebMessage {

    public EntryRoomComposer(Integer roomId, String roomName) {
        super("entryroom");
        this.data.add("roomid", new JsonPrimitive(roomId));
        this.data.add("roomname", new JsonPrimitive(roomName));
    }
}