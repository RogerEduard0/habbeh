package com.eu.habbo.phbsockets.websockets;

import com.eu.habbo.phbsockets.utils.JsonFactory;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClientManager;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;
import io.netty.channel.ChannelHandlerContext;

public class WebSocketChannelReadRunnable implements Runnable {
    private final ChannelHandlerContext ctx;
    private final String msg;

    public WebSocketChannelReadRunnable(ChannelHandlerContext ctx, String msg) {
        this.ctx = ctx;
        this.msg = msg;
    }

    public void run() {
        WebSocketClient client = this.ctx.channel().attr(WebSocketClientManager.CLIENT).get();
        if (client != null) {
            try {
                IncomingWebMessage.JSONIncomingEvent heading = JsonFactory.getInstance().fromJson(msg,  IncomingWebMessage.JSONIncomingEvent.class);
                Class<? extends IncomingWebMessage> message = WebSocketManager.getInstance().getIncomingMessages().get(heading.header);
                IncomingWebMessage webEvent = message.getDeclaredConstructor().newInstance();
                if(client.isAuthenticated() || webEvent.type.getName().contains("SSOTicketEvent") || webEvent.toString().contains("SSOTicketEvent")) {
                    webEvent.handle(client, JsonFactory.getInstance().fromJson(heading.data.toString(), webEvent.type));
                }
            } catch(Exception ex) {
            }
        }
    }

}
