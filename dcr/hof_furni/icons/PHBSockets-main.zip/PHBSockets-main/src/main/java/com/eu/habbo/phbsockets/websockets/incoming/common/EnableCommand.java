package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class EnableCommand extends IncomingWebMessage<EnableCommand.JsonEnableCommand> {

    public EnableCommand() {
        super(JsonEnableCommand.class);
    }

    @Override
    public void handle(WebSocketClient client, JsonEnableCommand message) {
        if(client.getHabbo().getHabboInfo().getCurrentRoom() == null)
            return;
       client.getHabbo().getHabboInfo().getCurrentRoom().giveEffect(client.getHabbo(), message.id, message.time);
    }

    static class JsonEnableCommand {
        Integer id;
        Integer time;
    }
}
