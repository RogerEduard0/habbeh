package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.common.ImageComposer;

public class RoomImageSocketCommand extends Command {
    public RoomImageSocketCommand(String permission, String[] keys) {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] strings) throws Exception {


        if (strings.length < 2) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_roomimage.url"));
            return false;
        }

        if (!strings[1].contains(".png") && !strings[1].contains(".jpg") && !strings[1].contains(".gif")) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_roomimage.url"));
            return false;
        }

        final Room room = gameClient.getHabbo().getHabboInfo().getCurrentRoom();
        String imageLink = strings[1].replace("http://", "https://").replaceAll("\\<.*?\\>", "").replace("document.", "").replace("\"", "").replace("'", "");

        if(!room.hasRights(gameClient.getHabbo())) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_roomimage.owner"));
            return false;
        }

        for (Habbo habbo : gameClient.getHabbo().getHabboInfo().getCurrentRoom().getHabbos()) {
            PHBWebSocket.sendWSForUser(new ImageComposer(imageLink),habbo);
        }

        return true;
    }
}


