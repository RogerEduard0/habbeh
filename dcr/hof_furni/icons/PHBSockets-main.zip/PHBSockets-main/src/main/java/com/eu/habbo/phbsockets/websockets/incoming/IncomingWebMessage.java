package com.eu.habbo.phbsockets.websockets.incoming;

import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.google.gson.JsonObject;

public abstract class IncomingWebMessage<T> {
    public final Class<T> type;

    public IncomingWebMessage(Class<T> type) {
        this.type = type;
    }

    public abstract void handle(WebSocketClient client, T message) throws InterruptedException;

    public static class JSONIncomingEvent {
        public String header;
        public JsonObject data;
    }
}
