package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.common.ImageComposer;

public class ColorADDCommand extends Command {
    public ColorADDCommand(String permission, String[] keys) {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] strings) throws Exception {
        PHBWebSocket.sendWSForUser(new ImageComposer(Emulator.getConfig().getValue("phbsockets.coloradd.imgurl")), gameClient.getHabbo());
        return true;
    }
}


