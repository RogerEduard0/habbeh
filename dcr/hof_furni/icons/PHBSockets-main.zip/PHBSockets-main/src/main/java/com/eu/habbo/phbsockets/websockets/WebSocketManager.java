package com.eu.habbo.phbsockets.websockets;

import com.eu.habbo.Emulator;
import com.eu.habbo.networking.Server;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClientManager;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;
import com.eu.habbo.phbsockets.websockets.incoming.common.*;
import com.eu.habbo.phbsockets.websockets.security.SSLCertificateLoader;
import gnu.trove.map.hash.THashMap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpServerCodec;
import io.netty.handler.codec.http.websocketx.WebSocketServerProtocolHandler;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.timeout.IdleStateHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebSocketManager extends Server {

    public static WebSocketManager instance;
    private static final Logger LOGGER = LoggerFactory.getLogger(WebSocketManager.class);
    private final WebSocketClientManager clientManager;
    private final THashMap<String, Class<? extends IncomingWebMessage>> incomingMessages;
    private final SslContext context;
    private final boolean SSL;

    public WebSocketManager() throws Exception {
        super("PHBSockets", Emulator.getConfig().getValue("phbsockets.host", "127.0.0.1"), Emulator.getConfig().getInt("phbsockets.port", 8443), 1, 2);
        this.clientManager = new WebSocketClientManager();
        this.incomingMessages = new THashMap<>();
        context = SSLCertificateLoader.getContext(Emulator.getConfig().getValue("ws.cert.pass", ""));
        SSL = context != null;
        initializeMessages();
    }

    public static void Init() {
        try {
            instance = new WebSocketManager();
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
        }
    }

    @Override
    public void initializePipeline() {
        super.initializePipeline();
        this.serverBootstrap.childHandler(new ChannelInitializer<SocketChannel>() {
            @Override
            public void initChannel(SocketChannel ch) throws Exception {
                if(SSL) {
                    ch.pipeline().addLast(context.newHandler(ch.alloc()));
                }
                ch.pipeline().addLast(new HttpServerCodec());
                ch.pipeline().addLast(new HttpObjectAggregator(65536));
                ch.pipeline().addLast(new WebSocketServerProtocolHandler("/", true));
                ch.pipeline().addLast(new IdleStateHandler(128, 10, 0));
                ch.pipeline().addLast(new WebSocketMessageHandler());
            }
        });
    }


    public void initializeMessages() {
        this.registerMessage("sso", SSOTicketEvent.class);
        this.registerMessage("pong", PongEvent.class);
        this.registerMessage("edit_tv", EditTVEvent.class);
        this.registerMessage("move_avatar", MoveAvatarEvent.class);
        this.registerMessage("reply_mention", ReplyMention.class);
        this.registerMessage("go_room", GoToRoomCommand.class);
        this.registerMessage("reply_user", ReplyUser.class);
        this.registerMessage("user_sex", SexCommand.class);
        this.registerMessage("user_slime", SlimeCommand.class);
        this.registerMessage("user_hug", HugCommand.class);
        this.registerMessage("user_kiss", KissCommand.class);
        this.registerMessage("user_bomb", NukeUser.class);
        this.registerMessage("user_push", PushCommand.class);
        this.registerMessage("user_pull", PullCommand.class);
        this.registerMessage("save_item", EditItemCommand.class);
        this.registerMessage("staff_effect", StaffEffectCommand.class);
    }

    public void registerMessage(String key, Class<? extends IncomingWebMessage> message) {
        this.incomingMessages.put(key, message);
    }

    public THashMap<String, Class<? extends IncomingWebMessage>> getIncomingMessages() {
        return this.incomingMessages;
    }

    public static WebSocketManager getInstance() {
        if (instance == null) {
            try {
                instance = new WebSocketManager();
            } catch (Exception e) {
                LOGGER.error(e.getMessage());
            }
        }
        return instance;
    }

    public WebSocketClientManager getClientManager() {
        return this.clientManager;
    }

    public boolean isSSL() {
        return SSL;
    }

    public void Dispose() {
        clientManager.dispose();
        incomingMessages.clear();
        instance = null;
    }

}
