package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class YoutubeTVComposer extends OutgoingWebMessage {
    public YoutubeTVComposer(int itemId, String json) {
        super("youtube_tv");
        this.data.add("itemId", new JsonPrimitive(itemId));
        this.data.add("playlist", new JsonPrimitive(json));
    }
}
