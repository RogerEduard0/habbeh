package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class CatalogWebsocketComposer extends OutgoingWebMessage {
    public CatalogWebsocketComposer(Integer itemId, String itemName, String publicName, String itemParams, Integer userId) {
        super("catalog");
        this.data.add("item_id", new JsonPrimitive(itemId));
        this.data.add("item_name", new JsonPrimitive(itemName));
        this.data.add("public_name", new JsonPrimitive(publicName));
        this.data.add("item_params", new JsonPrimitive(itemParams));
        this.data.add("user_id", new JsonPrimitive(userId));
    }
}