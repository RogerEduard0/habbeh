package com.eu.habbo.phbsockets;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.messenger.MessengerBuddy;
import com.eu.habbo.habbohotel.permissions.PermissionSetting;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.messages.ICallable;
import com.eu.habbo.messages.PacketManager;
import com.eu.habbo.messages.incoming.Incoming;
import com.eu.habbo.messages.incoming.MessageHandler;
import com.eu.habbo.phbsockets.composers.FurnitureClickedEvent;
import com.eu.habbo.phbsockets.composers.incoming.OverrideRequestWearingBadgesEvent;
import com.eu.habbo.phbsockets.composers.incoming.OverrideYoutubeRequestPlaylists;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.WebSocketManager;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.eu.habbo.phbsockets.websockets.outgoing.common.*;
import com.eu.habbo.plugin.EventHandler;
import com.eu.habbo.plugin.EventListener;
import com.eu.habbo.plugin.HabboPlugin;
import com.eu.habbo.plugin.events.emulator.EmulatorLoadedEvent;
import com.eu.habbo.plugin.events.users.*;
import gnu.trove.map.hash.THashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static com.eu.habbo.phbsockets.eventloader.LoadPermissions.checkDatabase;
import static com.eu.habbo.phbsockets.eventloader.PluginDatabaseRegister.checkPluginDB;
import static com.eu.habbo.phbsockets.eventloader.loadAll.loadAll;

public class Main extends HabboPlugin implements EventListener {
    public static Main INSTANCE = null;
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    @Override
    public void onEnable() {
        INSTANCE = this;
        Emulator.getPluginManager().registerEvents(this, this);
        if (Emulator.isReady) {
            checkDatabase();
            checkPluginDB();
        }
    }

    @Override
    public void onDisable() {
        WebSocketManager.getInstance().stop();
        WebSocketManager.getInstance().Dispose();
    }

    @Override
    public boolean hasPermission(Habbo habbo, String s) {
        return false;
    }

    @EventHandler
    public static void onEmulatorLoaded(EmulatorLoadedEvent event) throws Exception {
        checkDatabase();
        checkPluginDB();
        loadAll();

        final PacketManager packetManager = Emulator.getGameServer().getPacketManager();
        Field f = null;
        THashMap<Integer, Class<? extends MessageHandler>> incoming = null;
        try {
            f = PacketManager.class.getDeclaredField("incoming");
            f.setAccessible(true);
            incoming = (THashMap<Integer, Class<? extends MessageHandler>>) f.get(packetManager);
            incoming.remove(Incoming.RequestWearingBadgesEvent);
            Emulator.getGameServer().getPacketManager().registerHandler(Incoming.RequestWearingBadgesEvent, OverrideRequestWearingBadgesEvent.class);
            incoming.remove(Incoming.YoutubeRequestPlaylists);
            Emulator.getGameServer().getPacketManager().registerHandler(Incoming.YoutubeRequestPlaylists, OverrideYoutubeRequestPlaylists.class);
        } catch (Exception e) {
            LOGGER.error(e.getMessage());
        }

        final ICallable callable1 = (ICallable)new FurnitureClickedEvent();
        Emulator.getGameServer().getPacketManager().registerCallable(Integer.valueOf(99), callable1);
        Emulator.getGameServer().getPacketManager().registerCallable(Integer.valueOf(210), callable1);

        WebSocketManager.Init();
        WebSocketManager.getInstance().initializePipeline();
        WebSocketManager.getInstance().connect();

        LOGGER.info("[PHBSockets] - Websocket server started in " +
                (WebSocketManager.getInstance().isSSL() ? "wss" : "ws") + "://" +
                WebSocketManager.getInstance().getHost() + ":" + WebSocketManager.getInstance().getPort());
    }

    @EventHandler
    public void onUserCreditsEvent(UserCreditsEvent e) throws InterruptedException {
        PHBWebSocket.sendWSForUser(new UpdateCreditsComposer(e.credits), e.habbo);
    }

    @EventHandler
    public void UserEnterRoomEvent(UserEnterRoomEvent event) throws InterruptedException {
        PHBWebSocket.sendWSForUser(new EntryRoomComposer(event.room.getId(), event.room.getName()), event.habbo);
    }

    @EventHandler
    public void UserEnterRoomEvent(UserExitRoomEvent event) throws InterruptedException {
        PHBWebSocket.sendWSForUser(new ExitRoomComposer(), event.habbo);
    }

    @EventHandler
    public void onUserDisconnectEvent(UserDisconnectEvent e) {
        WebSocketClient conn = WebSocketManager.getInstance().getClientManager().getWebSocketClientForHabbo(e.habbo.getHabboInfo().getId());
        if(conn != null) {
            WebSocketManager.getInstance().getClientManager().disposeClient(conn);
        }
    }

    @EventHandler
    public static void onUserLoginEvent(UserLoginEvent event){
        PHBWebSocket.sendWSForUser(new SessionDataComposer(event.habbo.getHabboInfo().getId(), event.habbo.getHabboInfo().getUsername(), event.habbo.getHabboInfo().getCredits(), event.habbo.getHabboInfo().getLook()), event.habbo);
        try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT event_alert, sex_enabled FROM users WHERE id = ?")) {
            statement.setInt(1, event.habbo.getHabboInfo().getId());
            try (ResultSet set = statement.executeQuery()) {
                if (set.next()) {
                    event.habbo.getHabboStats().cache.put("event_alert", set.getString("event_alert"));
                    event.habbo.getHabboStats().cache.put("sex_enabled", set.getString("sex_enabled"));
                }
            }
        } catch (SQLException e) {
           LOGGER.error(e.getMessage());
        }
    }

    @EventHandler
    public void onUserTalk(com.eu.habbo.plugin.events.users.UserTalkEvent event){

        String fromPlayer = event.habbo.getHabboInfo().getUsername();
        String mensagem = event.chatMessage.getMessage();
        Integer roomid = event.habbo.getHabboInfo().getCurrentRoom().getId();

        /// Respoder menção.
        if (event.habbo.getHabboStats().cache.contains("replymention")) {
            Habbo habbo2 = Emulator.getGameEnvironment().getHabboManager().getHabbo(event.habbo.getHabboStats().cache.get("replymention").toString());
            if (habbo2 != null) {

                PHBWebSocket.sendWSForUser(new MentionComposer("@" + habbo2.getHabboInfo().getUsername() + " " + mensagem, fromPlayer, event.habbo.getHabboInfo().getId(), event.habbo.getHabboInfo().getLook(), roomid), habbo2);

                event.habbo.whisper(Emulator.getTexts().getValue("phbsockets.mention.replied").replace("%username%", habbo2.getHabboInfo().getUsername()));
                event.setCancelled(true);
                event.habbo.talk("@" + habbo2.getHabboInfo().getUsername() + " " + mensagem, event.chatMessage.getBubble());
                event.habbo.getHabboStats().cache.remove("replymention");

            } else {
                event.habbo.whisper(Emulator.getTexts().getValue("phbsockets.mention.invaliduser"));
            }
            event.habbo.getHabboStats().cache.remove("replymention");
        }

        /// Sistema de menção
        if (mensagem.length() > 3 && !event.habbo.getHabboStats().cache.contains("replymention")) {

            if (mensagem.startsWith("@")) {

                String mensagemCortada = mensagem.substring(1);
                String[] mensagemsplitada = mensagemCortada.split(" ");
                String para = mensagemsplitada[0];
                OutgoingWebMessage enviar = new MentionComposer(mensagem, fromPlayer, event.habbo.getHabboInfo().getId(), event.habbo.getHabboInfo().getLook(), roomid);

                /// @everyone
                if (event.habbo.getHabboInfo().getRank().getPermissions().get("acc_mention_everyone").setting == PermissionSetting.ALLOWED && para.equalsIgnoreCase("everyone")) {
                    PHBWebSocket.sendWSForAll(enviar);
                }

                /// @staff
                else if (event.habbo.getHabboInfo().getRank().getPermissions().get("acc_mention_staff").setting == PermissionSetting.ALLOWED && para.equals("staff") || event.habbo.getHabboInfo().getRank().getPermissions().get("acc_mention_staff").setting == PermissionSetting.ALLOWED && para.equals("sa")) {
                    for (Habbo habbo : Emulator.getGameEnvironment().getHabboManager().getOnlineHabbos().values()) {
                        if (habbo.getHabboInfo().getRank().getPermissions().get("acc_mention_staff").setting == PermissionSetting.DISALLOWED)
                            continue;
                        PHBWebSocket.sendWSForUser(enviar, habbo);
                    }
                    event.setCancelled(true);
                }

                // @room
                else if (event.habbo.getHabboInfo().getRank().getPermissions().get("acc_mention_room").setting == PermissionSetting.ALLOWED && para.equalsIgnoreCase("room")) {
                    for (Habbo habbo : event.habbo.getClient().getHabbo().getHabboInfo().getCurrentRoom().getHabbos()) {
                        PHBWebSocket.sendWSForUser(enviar, habbo);
                    }
                }

                // @friends
                else if (event.habbo.getHabboInfo().getRank().getPermissions().get("acc_mention_friends").setting == PermissionSetting.ALLOWED && para.equalsIgnoreCase("friends") || event.habbo.getHabboInfo().getRank().getPermissions().get("acc_mention_friends").setting == PermissionSetting.ALLOWED && para.equalsIgnoreCase("amigos")) {
                    for (MessengerBuddy user : event.habbo.getClient().getHabbo().getMessenger().getFriends().values()) {
                        if(user.getOnline() == 0)
                            continue;
                        Habbo habbo = Emulator.getGameEnvironment().getHabboManager().getHabbo(user.getUsername());
                        if(habbo == null)
                            continue;
                        PHBWebSocket.sendWSForUser(enviar, habbo);
                    }
                }

                /// @user
                else if (event.habbo.getHabboInfo().getRank().getPermissions().get("acc_mention_user").setting == PermissionSetting.ALLOWED) {
                    Habbo habbo = Emulator.getGameEnvironment().getHabboManager().getHabbo(para);
                    if (habbo == null || !habbo.isOnline()) {
                        event.habbo.whisper(Emulator.getTexts().getValue("phbsockets.mention.invaliduser"));
                    } else if (habbo.getHabboInfo().getId() == event.habbo.getHabboInfo().getId()) {
                        event.habbo.whisper(Emulator.getTexts().getValue("phbsockets.mention.needy"));
                    } else {
                        PHBWebSocket.sendWSForUser(enviar, habbo);
                    }
                }
            }
        }
    }

    public static void main(String[] args)
    {
        System.out.println("Don't run this separately");
    }
}