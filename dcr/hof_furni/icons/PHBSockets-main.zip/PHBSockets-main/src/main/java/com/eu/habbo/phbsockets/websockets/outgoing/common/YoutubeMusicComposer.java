package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class YoutubeMusicComposer extends OutgoingWebMessage {
    public YoutubeMusicComposer(String title, String id) {
        super("youtube_music");
        this.data.add("video_title", new JsonPrimitive(title));
        this.data.add("video_id", new JsonPrimitive(id));
    }
}