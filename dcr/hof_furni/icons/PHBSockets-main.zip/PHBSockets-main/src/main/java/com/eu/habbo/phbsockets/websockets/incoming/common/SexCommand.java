package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.permissions.PermissionSetting;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.rooms.RoomChatMessageBubbles;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class SexCommand extends IncomingWebMessage<SexCommand.JSONSexCommand> {

    public SexCommand() {
        super(JSONSexCommand.class);
    }

    @Override
    public void handle(WebSocketClient gameClient, JSONSexCommand message) throws InterruptedException {

        final Room room = gameClient.getHabbo().getHabboInfo().getCurrentRoom();

            Habbo habbo = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getHabbo(message.username);
            if (habbo != null) {

                if (habbo != gameClient.getHabbo()) {
                    if (habbo.getRoomUnit().getCurrentLocation().distance(gameClient.getHabbo().getRoomUnit().getCurrentLocation()) <= 1.5) {

                        habbo.getRoomUnit().lookAtPoint(gameClient.getHabbo().getRoomUnit().getCurrentLocation());
                        gameClient.getHabbo().getRoomUnit().lookAtPoint(habbo.getRoomUnit().getCurrentLocation());

                        /// Cooldown
                        Integer timestamp = Emulator.getIntUnixTimestamp();
                        Integer last_sex = 0;

                        if (gameClient.getHabbo().getHabboInfo().getRank().getPermissions().get("acc_override_sex").setting == PermissionSetting.DISALLOWED) {

                            /// Verifica se o próprio sexo tá ativo
                            if (gameClient.getHabbo().getHabboStats().cache.get("sex_enabled").equals("false")) {
                                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_sex.my.disabled"));
                                return;
                            }

                            /// Verifica se o sexo do user está ativo
                            if (habbo.getHabboStats().cache.get("sex_enabled").equals("false")) {
                                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_sex.user.disabled"));
                                return;
                            }

                        }

                        // Verifica se usuário pode executar comando
                        if(gameClient.getHabbo().getHabboStats().cache.contains("last_sex")) {

                            last_sex = Integer.parseInt(gameClient.getHabbo().getHabboStats().cache.get("last_sex").toString());
                            Integer cooldown = Integer.parseInt(Emulator.getConfig().getValue("phbsockets.sex.cooldown"));

                            ///Bypass
                            if (gameClient.getHabbo().getHabboInfo().getRank().getId() >= Integer.valueOf(Emulator.getConfig().getValue("phbsockets.rank.cooldown.bypass")))
                                last_sex = 0;

                            if (timestamp - last_sex < cooldown) {
                                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.cooldown.error").replace("%time%", ""+((last_sex + cooldown) - timestamp)));
                                return;
                            }
                        }

                        /// Adiciona o last sex na variável
                        gameClient.getHabbo().getHabboStats().cache.put("last_sex", timestamp);


                        /// Bota o efeito nos usuários
                        room.giveEffect(gameClient.getHabbo(), Emulator.getConfig().getInt("phbsockets.sex.enable"), 11);
                        room.giveEffect(habbo, Emulator.getConfig().getInt("phbsockets.sex.enable"), 11);

                        /// Realiza as falas de acordo com o gênero
                        // M & M
                        if(gameClient.getHabbo().getHabboInfo().getGender().toString().toLowerCase().contains("m") && habbo.getHabboInfo().getGender().toString().toLowerCase().contains("m")) {
                            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk1").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk2").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk3").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk4").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk5").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk6").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk7").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk8").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk9").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk10").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk11").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_m.talk12").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                        }
                        // F & F
                        else if(gameClient.getHabbo().getHabboInfo().getGender().toString().toLowerCase().contains("f") && habbo.getHabboInfo().getGender().toString().toLowerCase().contains("f")) {
                            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_f.talk1").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_f.talk2").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_f.talk3").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_f.talk4").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_f.talk5").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_f.talk6").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_f.talk7").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_f.talk8").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_f.talk9").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%user2%", gameClient.getHabbo().getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                        }
                        // M & F (F COMEÇA)
                        else if(habbo.getHabboInfo().getGender().toString().toLowerCase().contains("m") && gameClient.getHabbo().getHabboInfo().getGender().toString().toLowerCase().contains("f")) {

                            Habbo macho = habbo;
                            Habbo femea = gameClient.getHabbo();

                            if(gameClient.getHabbo().getHabboInfo().getGender().toString().toLowerCase().contains("m")) {
                                macho = gameClient.getHabbo();
                                femea = habbo;
                            }

                            femea.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_m.talk1").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            macho.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_m.talk2").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            femea.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_m.talk3").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            macho.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_m.talk4").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            femea.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_m.talk5").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            macho.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_m.talk6").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            macho.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_m.talk7").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            femea.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.f_m.talk8").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                        } else {
                            // M & F (M COMEÇA)
                            Habbo macho = habbo;
                            Habbo femea = gameClient.getHabbo();

                            if(gameClient.getHabbo().getHabboInfo().getGender().toString().toLowerCase().contains("m")) {
                                macho = gameClient.getHabbo();
                                femea = habbo;
                            }
                            macho.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_f.talk1").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            femea.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_f.talk2").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            macho.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_f.talk3").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            femea.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_f.talk4").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            macho.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_f.talk5").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            macho.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_f.talk6").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                            new Thread().sleep(1000);
                            femea.talk(Emulator.getTexts().getValue("commands.text.cmd_sex.m_f.talk7").replace("%f%", femea.getHabboInfo().getUsername()).replace("%m%", macho.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                        }
                    }
                    else {
                        gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_sex.distance"));
                    }
                }
                else {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_sex.needy"));
                }
            } else {
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_sex.error.user"));
            }
        return;
    }

    static class JSONSexCommand {
        String username;
    }
}
