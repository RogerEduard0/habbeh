package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class PingComposer extends OutgoingWebMessage {
    public PingComposer(String message) {
        super("ping");
        this.data.add("message", new JsonPrimitive(message));
    }
}
