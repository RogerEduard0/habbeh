package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class AddVideoYoutubeTvCommand extends Command {
    public AddVideoYoutubeTvCommand(String permission, String[] keys) {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] strings) throws Exception {

        if(Emulator.getConfig().getValue("phbsockets.youtube.apikey").length() < 5){
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.youtube.api.config"));
            return true;
        }
        if (strings.length < 2) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.cmd_addvideo.error"));
            return true;
        }
        String VideoName = "";
        if (strings.length > 1) {
            StringBuilder message = new StringBuilder();
            for (int i = 1; i < strings.length; i++) {
                message.append(strings[i]).append(" ");
            }
            VideoName = URLEncoder.encode(message.toString(), "UTF-8");
        }
        HttpURLConnection con = null;
        String title = null;
        String videoId = null;
        String channel = null;
        try {
            URL url = new URL("https://www.googleapis.com/youtube/v3/search?part=snippet&contentdetails&q="+VideoName+"&type=video&videoSyndicated=true&key="+Emulator.getConfig().getValue("phbplugin.cmd_youtube.apikey")+"&maxResults=1");
            con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            InputStream inStream = con.getInputStream();
            String jsonObtido = new Scanner(inStream, "UTF-8").useDelimiter("\\Z").next();
            JsonObject jsonObject = new Gson().fromJson(jsonObtido, JsonObject.class);
            if(jsonObject.getAsJsonArray("items").get(0).getAsJsonObject().get("id").getAsJsonObject().get("videoId") == null){
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.youtube.api.error"));
            } else {
                 title = jsonObject.getAsJsonArray("items").get(0).getAsJsonObject().get("snippet").getAsJsonObject().get("title").toString();
                 videoId = jsonObject.getAsJsonArray("items").get(0).getAsJsonObject().get("id").getAsJsonObject().get("videoId").toString();
                 channel = jsonObject.getAsJsonArray("items").get(0).getAsJsonObject().get("snippet").getAsJsonObject().get("channelTitle").toString();
            }
        } catch (Exception e) {
            e.printStackTrace();
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.youtube.api.error"));
            return true;
        } finally {
            if (con != null)
                con.disconnect();
            if(title != null && videoId != null && channel != null) {
                try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
                     PreparedStatement pstmt = connection.prepareStatement("INSERT INTO `phbplugin_youtubetv` (`user_id`, `video_id`, `video_title`, `video_channel`) VALUES (?, ?, ?, ?);", Statement.RETURN_GENERATED_KEYS)) {
                    pstmt.setInt(1, gameClient.getHabbo().getHabboInfo().getId());
                    pstmt.setString(2, videoId.replace("\"", ""));
                    pstmt.setString(3, title.replace("\"", ""));
                    pstmt.setString(4, channel.replace("\"", ""));
                    pstmt.execute();
                } catch (SQLException e) {
                    Emulator.getLogging().logSQLException(e);
                }
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.cmd_addvideo.success").replace("%title%", title).replace("%channel%", channel));
            }
            return true;
        }
    }
}