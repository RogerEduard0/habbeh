package com.eu.habbo.phbsockets.websockets.clients;

import com.eu.habbo.Emulator;
import com.eu.habbo.phbsockets.websockets.WebSocketManager;
import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelId;
import io.netty.util.AttributeKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public class WebSocketClientManager {
    public static final AttributeKey<WebSocketClient> CLIENT = AttributeKey.valueOf("WebSocketClient");
    private final ConcurrentMap<ChannelId, WebSocketClient> clients;
    private static final Logger LOGGER = LoggerFactory.getLogger(WebSocketManager.class);

    public WebSocketClientManager() {
        this.clients = new ConcurrentHashMap<>();
    }

    public boolean addClient(ChannelHandlerContext ctx) {
        WebSocketClient client = new WebSocketClient(ctx.channel());
        ctx.channel().closeFuture().addListener( (ChannelFutureListener) channelFuture ->
                this.disposeClient(ctx.channel())
        );

        ctx.channel().attr(CLIENT).set(client);
        ctx.fireChannelRegistered();

        return this.clients.putIfAbsent(ctx.channel().id(), client) == null;
    }

    public void broadcastMessage(OutgoingWebMessage message) {
        for (WebSocketClient client : this.clients.values()) {
            client.sendMessage(message);
        }
    }

    public void broadcastMessage(OutgoingWebMessage message, WebSocketClient exclude) {
        for (WebSocketClient client : this.clients.values()) {

            if (client.equals(exclude))
                continue;
            client.sendMessage(message);
        }
    }

    public void broadcastEventAlert(OutgoingWebMessage message) {
        for (WebSocketClient client : this.clients.values()) {
            if (client.getHabbo().getHabboStats().cache.get("event_alert").toString().equals("false")) {
                client.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_eventalert.disabledtext"));
            } else {
                client.sendMessage(message);
            }
        }
    }

    public void broadcastMessage(OutgoingWebMessage message, String minPermission, WebSocketClient exclude) {
        for (WebSocketClient client : this.clients.values()) {
            if (client.equals(exclude))
                continue;

            if (client.getHabbo() != null) {
                if (client.getHabbo().hasPermission(minPermission)) {
                    client.sendMessage(message);
                }
            }
        }
    }

    public ConcurrentMap<ChannelId, WebSocketClient> getClients() {
        return clients;
    }

    public WebSocketClient getWebSocketClientForHabbo(int id) {
        for(WebSocketClient client : this.clients.values()) {
            if(client.getHabbo() == null)
                continue;
            if(client.getHabbo().getHabboInfo().getId() == id)
                return client;
        }
        return null;
    }

    public boolean containsHabbo(Integer id) {
        if (!this.clients.isEmpty()) {
            for (WebSocketClient client : this.clients.values()) {
                if (client.getHabbo() != null) {
                    if (client.getHabbo().getHabboInfo() != null) {
                        if (client.getHabbo().getHabboInfo().getId() == id)
                            return true;
                    }
                }
            }
        }
        return false;
    }

    public void disposeClient(WebSocketClient client) {
        this.disposeClient(client.getChannel());
    }

    private void disposeClient(Channel channel) {
        WebSocketClient client = channel.attr(CLIENT).get();

        if (client != null) {
            if(client.getHabbo() != null)
                LOGGER.info("[PHBSockets] - "+client.getHabbo().getHabboInfo().getUsername() + " has been disconnected from the websocket server.");
            client.dispose();
        }
        channel.deregister();
        channel.attr(CLIENT).set(null);
        channel.closeFuture();
        channel.close();
        this.clients.remove(channel.id());
    }

    public void dispose() {
        clients.forEach( (k,v) -> {
            v.dispose();
            v.getChannel().deregister();
            v.getChannel().attr(CLIENT).set(null);
            v.getChannel().closeFuture();
            v.getChannel().close();
        });
        clients.clear();
    }
}
