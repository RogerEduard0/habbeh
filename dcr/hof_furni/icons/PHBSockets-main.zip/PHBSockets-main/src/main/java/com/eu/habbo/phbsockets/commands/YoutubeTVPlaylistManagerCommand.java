package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class YoutubeTVPlaylistManagerCommand extends Command
{
    public YoutubeTVPlaylistManagerCommand(String permission, String[] keys)
    {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] strings) throws Exception
    {
        if (strings.length < 2) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_managetv.error"));
            return true;
        }
        String opcao = strings[1];
        if(opcao.equalsIgnoreCase(Emulator.getTexts().getValue("commands.text.cmd_managetv.list"))) {
            StringBuilder message = new StringBuilder(Emulator.getTexts().getValue("commands.text.cmd_managetv.listing"));
            message.append("\r");
            try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
                 PreparedStatement statement = connection.prepareStatement("SELECT * FROM phbplugin_youtubetv WHERE user_id = ?;")) {
                statement.setInt(1, gameClient.getHabbo().getHabboInfo().getId());
                try (ResultSet set = statement.executeQuery()) {
                    while (set.next()) {
                        message.append("ID: "+set.getInt("id")+ "   -   "+set.getString("video_title")).append("\r");
                    }
                }
                message.append("\r"+ Emulator.getTexts().getValue("commands.text.cmd_managetv.howremove"));
            } catch (SQLException e) {
                Emulator.getLogging().logSQLException(e);
            }
            gameClient.getHabbo().alert(new String[]{message.toString()});
        }
        else if(opcao.equalsIgnoreCase(Emulator.getTexts().getValue("commands.text.cmd_managetv.remove"))) {
            if (strings.length < 3) {
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_managetv.error"));
                return true;
            }
            Integer id = Integer.parseInt(strings[2]);
            try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
                 PreparedStatement statement = connection.prepareStatement("DELETE FROM `phbplugin_youtubetv` WHERE user_id = ? AND id = ? LIMIT 1")) {
                statement.setInt(1, gameClient.getHabbo().getHabboInfo().getId());
                statement.setInt(2, id);
                statement.execute();
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_managetv.removed"));
            } catch (SQLException e) {
                Emulator.getLogging().logSQLException(e);
            }
        } else {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_managetv.error"));
            return true;
        }
        return true;
    }
}