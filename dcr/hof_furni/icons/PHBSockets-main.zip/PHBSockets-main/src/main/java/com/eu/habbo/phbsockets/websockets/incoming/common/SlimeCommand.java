package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.rooms.RoomUnitEffect;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class SlimeCommand extends IncomingWebMessage<SlimeCommand.JSONSlimeCommand> {

    public SlimeCommand() {
        super(JSONSlimeCommand.class);
    }

    @Override
    public void handle(WebSocketClient gameClient, JSONSlimeCommand message) throws InterruptedException {

        Habbo habbo = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getHabbo(message.username);

        if(habbo == null){
            return;
        }

        /// Cooldown
        Integer timestamp = Emulator.getIntUnixTimestamp();
        Integer last_cmd = 0;
        // Verifica se usuário pode executar comando
        if(gameClient.getHabbo().getHabboStats().cache.contains("last_slime")) {
            last_cmd = Integer.parseInt(gameClient.getHabbo().getHabboStats().cache.get("last_slime").toString());
            Integer cooldown = Integer.parseInt(Emulator.getConfig().getValue("phbsockets.slime.cooldown"));
            ///Bypass
            if (gameClient.getHabbo().getHabboInfo().getRank().getId() >= Integer.valueOf(Emulator.getConfig().getValue("phbsockets.rank.cooldown.bypass")))
                last_cmd = 0;
            if (timestamp - last_cmd < cooldown) {
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.cooldown.error").replace("%time%", String.valueOf(((last_cmd + cooldown) - timestamp))));
                return;
            }
        }
        gameClient.getHabbo().getHabboStats().cache.put("last_slime", timestamp);

        if (habbo != gameClient.getHabbo())
        {
            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_slime.throws").replace("%username%", habbo.getHabboInfo().getUsername()));

            Emulator.getThreading().run(() -> {
                if (gameClient.getHabbo().getHabboInfo().getRiding() != null) {
                    return;
                }

                else if (Emulator.getRandom().nextInt(100) < 20)
                {
                    gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_slime.missed").replace("%username%", habbo.getHabboInfo().getUsername()));
                    return;
                }

                gameClient.getHabbo().getHabboInfo().getCurrentRoom().giveEffect(habbo, RoomUnitEffect.SLIMED.getId(), 10);
                habbo.shout(Emulator.getTexts().getValue("commands.text.cmd_slime.slimed").replace("%username%", gameClient.getHabbo().getHabboInfo().getUsername()));
            }, (int)gameClient.getHabbo().getRoomUnit().getCurrentLocation().distance(habbo.getRoomUnit().getCurrentLocation()) * 100);
        }

        return;
    }

    static class JSONSlimeCommand {
        String username;
    }
}
