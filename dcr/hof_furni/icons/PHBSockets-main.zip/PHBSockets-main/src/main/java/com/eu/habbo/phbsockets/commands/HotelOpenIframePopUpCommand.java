package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.common.OpenUrlComposer;

public class HotelOpenIframePopUpCommand extends Command {
    public HotelOpenIframePopUpCommand(String permission, String[] keys) {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] strings) throws Exception {
        if (strings.length < 2) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_hoteliframe.error"));
            return false;
        }
        if (strings[1].contains("https://") || strings[1].contains("https://")) {
            PHBWebSocket.sendWSForAll(new OpenUrlComposer(strings[1], "popup"));
        } else {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_hoteliframe.error"));
        }
        return true;
    }
}