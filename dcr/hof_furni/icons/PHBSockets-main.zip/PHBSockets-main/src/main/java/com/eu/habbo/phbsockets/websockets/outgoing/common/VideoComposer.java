package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class VideoComposer extends OutgoingWebMessage {
    public VideoComposer(String tipo, String id) {
        super("video_phb");
        this.data.add("type", new JsonPrimitive(tipo));
        this.data.add("id", new JsonPrimitive(id));
    }
}