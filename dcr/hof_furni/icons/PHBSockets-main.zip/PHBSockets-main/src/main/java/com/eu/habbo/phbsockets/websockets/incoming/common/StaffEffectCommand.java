package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class StaffEffectCommand extends IncomingWebMessage<StaffEffectCommand.JsonEnableCommand> {

    public StaffEffectCommand() {
        super(JsonEnableCommand.class);
    }

    @Override
    public void handle(WebSocketClient client, JsonEnableCommand message) {

        if(client.getHabbo().getHabboInfo().getCurrentRoom() == null)
            return;

        if(client.getHabbo().getRoomUnit().getEffectId() == client.getHabbo().getHabboInfo().getRank().getRoomEffect())
            client.getHabbo().getHabboInfo().getCurrentRoom().giveEffect(client.getHabbo(),0, -1);
        else
            client.getHabbo().getHabboInfo().getCurrentRoom().giveEffect(client.getHabbo(), client.getHabbo().getHabboInfo().getRank().getRoomEffect(), -1);

    }

    static class JsonEnableCommand {
    }
}
