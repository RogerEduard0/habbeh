package com.eu.habbo.phbsockets.composers;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.catalog.CatalogItem;
import com.eu.habbo.habbohotel.items.Item;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.habbohotel.users.HabboBadge;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.habbohotel.users.inventory.BadgesComponent;
import com.eu.habbo.messages.outgoing.inventory.InventoryBadgesComposer;
import com.eu.habbo.messages.outgoing.inventory.InventoryRefreshComposer;
import com.eu.habbo.messages.outgoing.users.UserBadgesComposer;
import com.eu.habbo.phbsockets.interactiontypes.InteractionWebsocket;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.common.CatalogWebsocketComposer;
import com.eu.habbo.plugin.EventHandler;
import com.eu.habbo.plugin.EventListener;
import com.eu.habbo.plugin.events.users.catalog.UserCatalogItemPurchasedEvent;
import gnu.trove.set.hash.THashSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class HabboPurchasesCatalogItemEvent implements EventListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(HabboPurchasesCatalogItemEvent.class);

    @EventHandler
    public static void PurchasesItem(UserCatalogItemPurchasedEvent event) throws Exception
    {
        THashSet<HabboItem> itemsList = event.itemsList;
        CatalogItem items = event.catalogItem;
        List<String> badgesList = event.badges;

        for (Item s : event.catalogItem.getBaseItems()) {
            Item itembuy = Emulator.getGameEnvironment().getItemManager().getItem(s.getId());
            if (itembuy != null) {
                if(itembuy.getInteractionType().getType() == InteractionWebsocket.class){
                    PHBWebSocket.sendWSForUser(new CatalogWebsocketComposer(itembuy.getId(), itembuy.getName(), itembuy.getFullName(), itembuy.getCustomParams(), event.habbo.getHabboInfo().getId()), event.habbo);
                }
            }
        }

        for (HabboItem habboItem: itemsList) {
            // Websocket
            if(habboItem.getBaseItem().getInteractionType().getType() == InteractionWebsocket.class){
                RemoveFurni(habboItem.getId(), event.habbo); /// Remove o mobi
                PHBWebSocket.sendWSForUser(new CatalogWebsocketComposer(habboItem.getBaseItem().getId(), habboItem.getBaseItem().getName(), habboItem.getBaseItem().getFullName(), habboItem.getBaseItem().getCustomParams(), event.habbo.getHabboInfo().getId()), event.habbo);
            }
        }

    }

    public static void RemoveBadge(String badge, Habbo habbo) throws InterruptedException {
        Emulator.getThreading().run(new Runnable() {
            @Override
            public void run() {
                Boolean repeat = true;
                while(repeat) {
                    String username = habbo.getHabboInfo().getUsername();
                    Habbo habbo = Emulator.getGameEnvironment().getHabboManager().getHabbo(username);
                    if (habbo != null) {
                        HabboBadge b = habbo.getInventory().getBadgesComponent().removeBadge(badge);
                        if (b != null) {
                            habbo.getClient().sendResponse(new InventoryBadgesComposer(habbo));
                            if (habbo.getHabboInfo().getCurrentRoom() != null) {
                                habbo.getHabboInfo().getCurrentRoom().sendComposer(new UserBadgesComposer(habbo.getInventory().getBadgesComponent().getWearingBadges(), habbo.getHabboInfo().getId()).compose());
                            } else {
                                repeat = false;
                            }
                        } else {
                            repeat = false;
                        }
                    } else {
                        repeat = false;
                    }
                    BadgesComponent.deleteBadge(username, badge);
                }
            }});
    }

    public static void RemoveFurni(Integer item, Habbo habbo) throws InterruptedException {
        Emulator.getThreading().run(new Runnable() {
            @Override
            public void run() {
                if(habbo.getInventory().getItemsComponent().getItems().containsKey(item)){
                    if (habbo != null) {
                        Emulator.getThreading().run(this).cancel(true);
                        HabboItem itemm = habbo.getInventory().getItemsComponent().getHabboItem(item);
                        if(itemm != null) {
                            Emulator.getGameEnvironment().getItemManager().deleteItem(itemm);
                            habbo.getInventory().getItemsComponent().removeHabboItem(itemm);
                            habbo.getInventory().getItemsComponent().getItems().remove(item);
                            habbo.getClient().sendResponse(new InventoryRefreshComposer());
                        }
                    }
                } else {
                    Emulator.getThreading().run(this, 500);
                }
            }});
    }
}
