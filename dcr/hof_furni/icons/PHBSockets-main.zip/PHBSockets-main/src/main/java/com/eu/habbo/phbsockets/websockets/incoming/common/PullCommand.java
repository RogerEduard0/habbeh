package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.rooms.RoomChatMessage;
import com.eu.habbo.habbohotel.rooms.RoomChatMessageBubbles;
import com.eu.habbo.habbohotel.rooms.RoomTile;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.habbohotel.users.HabboGender;
import com.eu.habbo.messages.outgoing.rooms.users.RoomUserTalkComposer;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class PullCommand extends IncomingWebMessage<PullCommand.JSONPuxarCommand> {

    public PullCommand() {
        super(JSONPuxarCommand.class);
    }

    @Override
    public void handle(WebSocketClient gameClient, JSONPuxarCommand message) throws InterruptedException {

        Habbo habbo = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getHabbo(message.username);

        if (habbo == null) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.error.cmd_pull.not_found").replace("%user%", habbo.getHabboInfo().getUsername()), RoomChatMessageBubbles.ALERT);
            return;
        } else if (habbo == gameClient.getHabbo()) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.error.cmd_pull.pull_self"), RoomChatMessageBubbles.ALERT);
            return;
        } else {
            int distanceX = habbo.getRoomUnit().getX() - gameClient.getHabbo().getRoomUnit().getX();
            int distanceY = habbo.getRoomUnit().getY() - gameClient.getHabbo().getRoomUnit().getY();

            if (distanceX < -2 || distanceX > 2 || distanceY < -2 || distanceY > 2) {
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.error.cmd_pull.cant_reach").replace("%user%", habbo.getHabboInfo().getUsername()), RoomChatMessageBubbles.ALERT);
                return;
            } else {

                /// Cooldown
                Integer timestamp = Emulator.getIntUnixTimestamp();
                Integer last_cmd = 0;
                // Verifica se usuário pode executar comando
                if(gameClient.getHabbo().getHabboStats().cache.contains("last_puxar")) {
                    last_cmd = Integer.parseInt(gameClient.getHabbo().getHabboStats().cache.get("last_puxar").toString());
                    Integer cooldown = Integer.parseInt(Emulator.getConfig().getValue("phbsockets.pull.cooldown"));
                    ///Bypass
                    if (gameClient.getHabbo().getHabboInfo().getRank().getId() >= Integer.valueOf(Emulator.getConfig().getValue("phbsockets.rank.cooldown.bypass")))
                        last_cmd = 0;
                    if (timestamp - last_cmd < cooldown) {
                        gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.cooldown.error").replace("%time%", String.valueOf(((last_cmd + cooldown) - timestamp))));
                        return;
                    }
                }

                gameClient.getHabbo().getHabboStats().cache.put("last_puxar", timestamp);

                RoomTile tile = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getLayout().getTileInFront(gameClient.getHabbo().getRoomUnit().getCurrentLocation(), gameClient.getHabbo().getRoomUnit().getBodyRotation().getValue());

                if (tile != null && tile.isWalkable()) {
                    if (gameClient.getHabbo().getHabboInfo().getCurrentRoom().getLayout().getDoorTile() == tile) {
                        gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.error.cmd_pull.invalid").replace("%username%", habbo.getHabboInfo().getUsername()));
                        return;
                    }
                    habbo.getRoomUnit().setGoalLocation(tile);
                    gameClient.getHabbo().getHabboInfo().getCurrentRoom().sendComposer(new RoomUserTalkComposer(new RoomChatMessage(Emulator.getTexts().getValue("commands.succes.cmd_pull.pull").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%gender_name%", (gameClient.getHabbo().getHabboInfo().getGender().equals(HabboGender.M) ? Emulator.getTexts().getValue("gender.him") : Emulator.getTexts().getValue("gender.her"))), gameClient.getHabbo(), gameClient.getHabbo(), RoomChatMessageBubbles.NORMAL)).compose());
                }
            }
        }
    }

    static class JSONPuxarCommand {
        String username;
    }
}
