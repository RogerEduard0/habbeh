package com.eu.habbo.phbsockets.eventloader;

import com.eu.habbo.Emulator;
import com.eu.habbo.phbsockets.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoadTextsPT {
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    public static void loadTexts() {
        try {
            LOGGER.info("[PHBSockets] - Loading texts...");

            Emulator.getTexts().register("commands.cmd_eventalert.keys", "eha;evento");
            Emulator.getTexts().register("commands.description.cmd_eventalert", ":eha - Alerta de evento");
            Emulator.getTexts().register("commands.text.cmd_eventalert.disabledtext", "Um novo evento está acontecendo! use :eventosoff para ativar os alertas.");

            Emulator.getTexts().register("commands.cmd_roomvideo.keys", "roomvideo");
            Emulator.getTexts().register("commands.description.cmd_roomvideo", ":roomvideo - Abre um vídeo no quarto");
            Emulator.getTexts().register("commands.text.cmd_roomvideo.error", "Você não enviou um link válido! (Youtube, Twitch, Facebook, Xvideos ou PornHUB)");
            Emulator.getTexts().register("commands.text.cmd_roomvideo.owner", "Você não pode usar esse comando aqui.");

            Emulator.getTexts().register("commands.cmd_hotelvideo.keys", "hotelvideo");
            Emulator.getTexts().register("commands.description.cmd_hotelvideo", ":hotelvideo link");

            Emulator.getTexts().register("commands.cmd_disablealertevent.keys", "eventsoff;eventosoff");
            Emulator.getTexts().register("commands.description.cmd_disablealertevent", ":eventosoff");
            Emulator.getTexts().register("commands.text.cmd_disablealertevent.disabled", "Você não irá receber alertas de evento!");
            Emulator.getTexts().register("commands.text.cmd_disablealertevent.enabled", "Você irá receber alertas de evento!");

            Emulator.getTexts().register("commands.description.cmd_furnidata", ":furnidata");
            Emulator.getTexts().register("commands.cmd_furnidata.keys", "furnidata");
            Emulator.getTexts().register("commands.cmd_furnidata.on", "Comando furnidata ativo!");
            Emulator.getTexts().register("commands.cmd_furnidata.off", "Comando furnidata desativado!");

            Emulator.getTexts().register("phbsockets.mention.needy", "Você não pode mencionar você mesmo, está carente?");
            Emulator.getTexts().register("phbsockets.mention.invaliduser", "Você tentou mencionar um usuário que está offline ou não existe.");
            Emulator.getTexts().register("phbsockets.mention.reply", "A próxima mensagem será enviada para %username%.");
            Emulator.getTexts().register("phbsockets.mention.replied", "Sua mensagem foi enviada para %username%.");

            Emulator.getTexts().register("commands.cmd_roomimage.keys", "roomimage");
            Emulator.getTexts().register("commands.description.cmd_roomimage", ":roomimage - Abre uma imagem no quarto.");
            Emulator.getTexts().register("commands.text.cmd_roomimage.url", "Você não enviou um link válido.");
            Emulator.getTexts().register("commands.text.cmd_roomimage.owner", "Você não pode usar o comando aqui.");

            Emulator.getTexts().register("commands.cmd_hotelimage.keys", "hotelimage");
            Emulator.getTexts().register("commands.description.cmd_hotelimage", ":hotelimage - Abre uma imagem em todo o hotel.");

            Emulator.getTexts().register("commands.cmd_edititem.keys", "edititem;editaritem");
            Emulator.getTexts().register("commands.description.cmd_edititem", ":editaritem - Edita um item");
            Emulator.getTexts().register("commands.text.cmd_edititem.invalidfurni", "O item %id% não existe!");
            Emulator.getTexts().register("commands.text.cmd_edititem.invalidparam", "Parâmetros inválidos.");
            Emulator.getTexts().register("commands.text.cmd_edititem.error", "Houve um erro ao executar o comando, verifique se as informações enviadas estão corretas.");
            Emulator.getTexts().register("commands.text.cmd_edititem.success", "O parâmetro %param% do item %id% foi definido como %value%.");
            Emulator.getTexts().register("commands.text.cmd_edititem.success.ws", "Você editou o item %id%.");
            Emulator.getTexts().register("commands.text.cmd_edititem.disabled", "Editor de items desativado");
            Emulator.getTexts().register("commands.text.cmd_edititem.enabled", "Dê um duplo clique em um mobi para editar.");
            Emulator.getTexts().register("commands.text.cmd_edititem.example1", "Exemplo: :editaritem 4768 allow_sit 1");
            Emulator.getTexts().register("commands.text.cmd_edititem.example2", "Você também pode usar :editaritem id para abrir o menu de edição.");
            Emulator.getTexts().register("commands.text.cmd_edititem.example3", "Caso você deseja desativar o menu, use :editaritem id parâmetro valor, exemplo: :edititem 1 allow_sit 1");

            Emulator.getTexts().register("phbsockets.youtube.api.error", "Erro com a API do Youtube, tente novamente mais tarde..");
            Emulator.getTexts().register("phbsockets.youtube.api.config", "A API do Youtube está desconfigurada, configure em emulator_settings.");

            Emulator.getTexts().register("commands.cmd_youtube.keys", "youtube");
            Emulator.getTexts().register("commands.description.cmd_youtube", ":youtube - Pesquisar um vídeo no Youtube");
            Emulator.getTexts().register("commands.texts.cmd_youtube.error", "Você não digitou um título válido.");
            Emulator.getTexts().register("commands.texts.cmd_youtube.success", "Transmitindo \"%title%\" no quarto");

            Emulator.getTexts().register("commands.cmd_addvideo_youtubetv.keys", "addvideo");
            Emulator.getTexts().register("commands.description.cmd_addvideo_youtubetv", ":addvideo - Adiciona um vídeo à TV Youtube");
            Emulator.getTexts().register("commands.cmd_addvideo_youtubetv.error", "Você não digitou um título válido para adicionar à sua Playlist");
            Emulator.getTexts().register("commands.cmd_addvideo_youtubetv.success", "O vídeo %title% do canal %channel% foi adicionado na sua Playlist.");

            Emulator.getTexts().register("commands.cmd_manage_youtubetv.keys", "managetv;gerenciartv");
            Emulator.getTexts().register("commands.description.cmd_manage_youtubetv", ":gerenciartv - Gerenciar sua TV Youtube");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.list", "lista");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.remove", "remover");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.error", "Você deve digitar :gerenciartv lista ou :gerenciartv remover id.");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.listing", "Listagem de vídeos na sua Playlist:");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.howremove", "Para remover um vídeo, use :gerenciartv remover id");
            Emulator.getTexts().register("commands.text.cmd_manage_youtubetv.removed", "O vídeo foi removido de sua playlist.");

            Emulator.getTexts().register("commands.cmd_youtubemusic.keys", "roommusic;musica;music;youtubemusic;musicayoutube");
            Emulator.getTexts().register("commands.description.cmd_youtubemusic", ":musica");
            Emulator.getTexts().register("commands.text.cmd_youtubemusic.success", "Transmitindo a música \"%title%\" no quarto.");

            Emulator.getTexts().register("commands.cmd_roomiframe.keys", "roomiframe");
            Emulator.getTexts().register("commands.description.cmd_roomiframe", ":roomiframe");
            Emulator.getTexts().register("commands.text.cmd_roomiframe", ":roomiframe");
            Emulator.getTexts().register("commands.text.cmd_roomiframe.error", "Você deve usar :roomiframe url");
            Emulator.getTexts().register("commands.text.cmd_roomiframe.owner", "Você não pode usar esse comando no quarto.");

            Emulator.getTexts().register("commands.cmd_hoteliframe.keys", "hoteliframe");
            Emulator.getTexts().register("commands.text.cmd_hoteliframe", ":hoteliframe - Exibe um iframe popup");
            Emulator.getTexts().register("commands.text.cmd_hoteliframe.error", "Você deve usar :hoteliframe url");

            Emulator.getTexts().register("commands.cmd_disablesex.keys", "disablesex;desativarsexo");
            Emulator.getTexts().register("commands.description.cmd_disablesex", ":desativarsexo - Desativa o comando de sexo");
            Emulator.getTexts().register("commands.text.cmd_disablesex.disabled", "Agora você não pode fazer sexo.");
            Emulator.getTexts().register("commands.text.cmd_disablesex.enabled", "Agora você pode fazer sexo.");

            Emulator.getTexts().register("phbsockets.cooldown.error", "Você precisa aguardar %time% segundos para usar esse comando novamente.");

            Emulator.getTexts().register("commands.cmd_sex.keys", "sexo;transar;sex");
            Emulator.getTexts().register("commands.description.cmd_sex", ":sexo - Faz sexo com um usuário");
            Emulator.getTexts().register("commands.text.cmd_sex.my.disabled", "Você não pode usar esse comando com o sexo desativado, use :desativarsexo para ativar e tente novamente.");
            Emulator.getTexts().register("commands.text.cmd_sex.user.disabled", "O usuário desativou o sexo.");
            Emulator.getTexts().register("commands.text.cmd_sex.distance", "O usuário está longe, chegue mais perto e tente novamente.");
            Emulator.getTexts().register("commands.text.cmd_sex.needy", "Você não pode fazer sexo com você mesmo, está carente?");
            Emulator.getTexts().register("commands.text.cmd_sex.error.user", "Usuário não encontrado!");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk1", "*Botando com força no buraco do %user%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk2", "*Empurro com força no %user%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk3", "*Ohaaaaaaaaaaaaaar*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk4", "*Que pau de jegue %user2%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk5", "*Não enfia tudo, tá doendo*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk6", "*Aiiii pai paraaaaaa*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk7", "*Não bota tudõo que eu piro aloka*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk8", "*Eu to pro crime hoje*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk9", "**Ain que pauzinho gostoso*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk10", "*Aahhhhhhhhhhhhhhr*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk11", "*Mete gostosinho no meu cuzinho vai dlç*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_m.talk12", "*Gozei litros dentro do %user%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk1", "*Colando velcro com a %user%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk2", "*Puxa delicadamente para não raspar os pelos da %user%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk3", "*nheeeeeeeeeeeec*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk4", "*ohaaaaaaaaaaaaaaaaar*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk5", "*Esfrega vai, esfregaa*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk6", "*Esfrega mais rápido*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk7", "*Faz aquela posição que eu piro*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk8", "*Sentindo prazer*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_f.talk9", "*Corta as unhas e faz o dj em mim amor*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk1", "*Botando na xavasca da %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk2", "*AAAAAAIN QUE DELÍÍÍCIA, FODE ESSA BUCETAAA!*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk3", "*Empurrando com força na %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk4", "*Ain pai paraaa, vai devagar, seu gostoso!*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk5", "*Empurra rapidamente o cano do fuzil*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk6", "*Retirando a jeba da prexeca da %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.m_f.talk7", "*Que gostoso seu pirocudo, fode mais, vai*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk1", "*Seduzindo o %m%, VEM E EMPURRA TUDO NA MINHA XOXOTINHA*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk2", "*Botando na xavasca da %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk3", "*AAAAAAIN QUE DELÍÍÍCIA, FODE ESSA BUCETAAA!*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk4", "*Empurrando com força na %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk5", "*Ain pai paraaa, vai devagar, seu gostoso!*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk6", "*Empurra rapidamente o cano do fuzil*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk7", "*Retirando a jeba da prexeca da %f%*");
            Emulator.getTexts().register("commands.text.cmd_sex.f_m.talk8", "*Que gostoso seu pirocudo, fode mais, vai*");

            Emulator.getTexts().register("commands.description.cmd_slime", ":slime <username>");
            Emulator.getTexts().register("commands.cmd_slime.keys", "slime;slimed;goop;nickelodeon");
            Emulator.getTexts().register("commands.text.cmd_slime.throws", "*Joga slime na direção de %username%*");
            Emulator.getTexts().register("commands.text.cmd_slime.missed", "*Errou a mira*");
            Emulator.getTexts().register("commands.text.cmd_slime.slimed", "*Cobre %username% de slime*");

            Emulator.getTexts().register("phbsockets.followuser.error", "Você já está nesse quarto!");

            Emulator.getTexts().register("commands.description.cmd_nuke", ":explodir <username>");
            Emulator.getTexts().register("commands.cmd_nuke.keys", "nuke;nade;grenade;explode;boom;explodir");
            Emulator.getTexts().register("commands.text.nuke.self", "Você não pode explodir você mesmo, seu terrorista!");
            Emulator.getTexts().register("commands.text.nuke.action", "*Joga uma bomba em %username%*");
            Emulator.getTexts().register("commands.text.nuke.nuked", "*%username% foi exterminado*");

            Emulator.getTexts().register("commands.description.cmd_hug", ":abracar <username>");
            Emulator.getTexts().register("commands.cmd_hug.keys", "hug;cuddle;abracar");
            Emulator.getTexts().register("commands.text.cmd_hug.huggedperson", "*Dando um abraço no %hugger%*");
            Emulator.getTexts().register("commands.text.cmd_hug.hugger", "*Recebe um abraço de %huggedperson%*");
            Emulator.getTexts().register("commands.text.cmd_hug.tofar", "%huggedperson% está longe para ser abraçado, chegue mais perto e tente novamente.");

            Emulator.getTexts().register("commands.cmd_coloradd.keys", "coloradd");
            Emulator.getTexts().register("commands.description.cmd_coloradd", ":coloradd - Assistência para daltônicos.");

            Emulator.getTexts().register("commands.description.cmd_cataltd", ":cataltd - Atualiza o catálogo e envia um alerta.");
            Emulator.getTexts().register("commands.cmd_cataltd.keys", "cataltd");

            Emulator.getTexts().register("commands.texts.cmd_kiss.kiss", "*Beijando %username%*");

            Emulator.getTexts().register("commands.text.cmd_disablesex.enabled", "O sexo foi ativado!");
            Emulator.getTexts().register("commands.text.cmd_disablesex.disabled", "O sexo foi desativado!");
            Emulator.getTexts().register("commands.cmd_disablesex.keys", "disablesex;enablesex;desativarsexo");
            Emulator.getTexts().register("commands.description.cmd_disablesex", ":desativarsexo - Ativa/desativa sexo.");
        } catch (Exception ex) {
           LOGGER.info(ex.getMessage());
        }
    }
}
