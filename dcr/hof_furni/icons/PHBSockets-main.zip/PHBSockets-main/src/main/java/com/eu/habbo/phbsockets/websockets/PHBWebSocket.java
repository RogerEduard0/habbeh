package com.eu.habbo.phbsockets.websockets;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.permissions.PermissionSetting;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;

import java.util.Map;

public class PHBWebSocket {

    public static void sendWSForAll(OutgoingWebMessage enviar) {
        for (Map.Entry<Integer, Habbo> set : Emulator.getGameEnvironment().getHabboManager().getOnlineHabbos().entrySet()) {
            Habbo habbo2 = set.getValue();
            if (habbo2.isOnline()) {
                sendWSForUser(enviar, habbo2);
            }
        }
    }

    public static void sendWSForAllEvent(OutgoingWebMessage enviar, Integer roomId)  {
        for (Map.Entry<Integer, Habbo> set : Emulator.getGameEnvironment().getHabboManager().getOnlineHabbos().entrySet()) {
            Habbo habbo2 = set.getValue();
            if (habbo2.isOnline()) {
                if (habbo2.getHabboStats().cache.get("event_alert").toString().equals("false")) {
                    habbo2.whisper(Emulator.getTexts().getValue("commands.text.cmd_eventalert.disabledtext"));
                } else {
                    sendWSForUser(enviar, habbo2);
                }
            }
        }
    }

    public static void sendWSForUser(OutgoingWebMessage enviar, Habbo user) {
        WebSocketClient wsClient = WebSocketManager.getInstance().getClientManager().getWebSocketClientForHabbo(user.getHabboInfo().getId());
        if (wsClient != null) {
            wsClient.sendMessage(enviar);
        }
    }

}
