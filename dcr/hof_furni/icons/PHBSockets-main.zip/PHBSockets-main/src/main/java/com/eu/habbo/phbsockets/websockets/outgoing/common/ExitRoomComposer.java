package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;

public class ExitRoomComposer extends OutgoingWebMessage {
    public ExitRoomComposer() {
        super("exit_room");
    }
}