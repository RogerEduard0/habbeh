package com.eu.habbo.phbsockets.eventloader;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.CommandHandler;
import com.eu.habbo.phbplugin.commands.DisableSexCommand;
import com.eu.habbo.phbsockets.Main;
import com.eu.habbo.phbsockets.commands.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoadPlayerCommands {
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    public static void loadPlayerCommands() {
        try {
            LOGGER.info("[PHBSockets] - Loading commands...");
            CommandHandler.addCommand(new EventAlertSocketCommand("cmd_eventalert", Emulator.getTexts().getValue("commands.cmd_eventalert.keys").split(";")));
            CommandHandler.addCommand(new RoomVideoSocketCommand("cmd_roomvideo", Emulator.getTexts().getValue("commands.cmd_roomvideo.keys").split(";")));
            CommandHandler.addCommand(new HotelVideoSocketCommand("cmd_hotelvideo", Emulator.getTexts().getValue("commands.cmd_hotelvideo.keys").split(";")));
            CommandHandler.addCommand(new FurniDataCommand("cmd_furnidata", Emulator.getTexts().getValue("commands.cmd_furnidata.keys").split(";")));
            CommandHandler.addCommand(new RoomImageSocketCommand("cmd_roomimage", Emulator.getTexts().getValue("commands.cmd_roomimage.keys").split(";")));
            CommandHandler.addCommand(new HotelImageSocketCommand("cmd_hotelimage", Emulator.getTexts().getValue("commands.cmd_hotelimage.keys").split(";")));
            CommandHandler.addCommand(new ColorADDCommand("cmd_coloradd", Emulator.getTexts().getValue("commands.cmd_coloradd.keys").split(";")));
            CommandHandler.addCommand(new EditItemCommand("cmd_edititem", Emulator.getTexts().getValue("commands.cmd_edititem.keys").split(";")));
            CommandHandler.addCommand(new CholaMaisCommand());
            CommandHandler.addCommand(new YoutubeCommand("cmd_youtube", Emulator.getTexts().getValue("commands.cmd_youtube.keys").split(";")));
            CommandHandler.addCommand(new AddVideoYoutubeTvCommand("cmd_addvideo_youtubetv", Emulator.getTexts().getValue("commands.cmd_addvideo_youtubetv.keys").split(";")));
            CommandHandler.addCommand(new YoutubeTVPlaylistManagerCommand("cmd_manage_youtubetv", Emulator.getTexts().getValue("commands.cmd_manage_youtubetv.keys").split(";")));
            CommandHandler.addCommand(new RoomYoutubeMusicSocketCommand("cmd_youtubemusic", Emulator.getTexts().getValue("commands.cmd_youtubemusic.keys").split(";")));
            CommandHandler.addCommand(new RoomOpenIframePopUpCommand("cmd_roomiframe", Emulator.getTexts().getValue("commands.cmd_roomiframe.keys").split(";")));
            CommandHandler.addCommand(new HotelOpenIframePopUpCommand("cmd_hoteliframe", Emulator.getTexts().getValue("commands.cmd_hoteliframe.keys").split(";")));
            CommandHandler.addCommand(new DisableEventAlertCommand("cmd_disablealertevent", Emulator.getTexts().getValue("commands.cmd_disablealertevent.keys").split(";")));
            CommandHandler.addCommand(new DisableSexCommand("cmd_disablesex", Emulator.getTexts().getValue("commands.cmd_disablesex.keys").split(";")));
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage());
        }
    }
}
