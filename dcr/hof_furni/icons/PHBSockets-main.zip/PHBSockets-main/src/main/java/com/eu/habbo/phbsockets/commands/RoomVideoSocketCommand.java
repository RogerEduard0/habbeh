package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.eu.habbo.phbsockets.websockets.outgoing.common.VideoComposer;

public class RoomVideoSocketCommand extends Command {
    public RoomVideoSocketCommand(String permission, String[] keys) {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] strings) throws Exception {
        if (strings.length < 2) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_roomvideo.error"));
            return false;
        }

        final Room room = gameClient.getHabbo().getHabboInfo().getCurrentRoom();
        String videolink = strings[1].replace("http://", "https://").replaceAll("\\<.*?\\>", "").replace("document.", "").replace("\"", "").replace("'", "");;
        String VideoId = "";
        OutgoingWebMessage enviar = null;

        if(!room.hasRights(gameClient.getHabbo())) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_roomvideo.owner"));
            return false;
        }
        /// Youtube JSON
        if (videolink.contains("https://www.youtube.com/watch?v=") || videolink.contains("https://youtu.be/")) {
            /// Obtem o ID do vídeo
            if (videolink.contains("https://www.youtube.com/watch?v=")) {
                VideoId = videolink.replace("https://www.youtube.com/watch?v=", "");
                VideoId = VideoId.split("&")[0];
            } else if (videolink.contains("https://youtu.be/")) {
                VideoId = videolink.replace("https://youtu.be/", "");
            }
            enviar = new VideoComposer("youtube", VideoId);
        }
        /// Twitch JSON
        else if (videolink.contains("https://www.twitch.tv/")) {
            /// Obtem o ID do vídeo
            VideoId = videolink.replace("https://www.twitch.tv/", "");
            enviar = new VideoComposer("twitch", VideoId);
        }
        /// Facebook JSON
        else if (videolink.contains("facebook.com") && videolink.contains("videos/")) {
            enviar = new VideoComposer("facebook", videolink);
        }
        /// PornHUB JSON
        else if (videolink.contains("pornhub.com")) {
            VideoId = videolink.replace("https://www.pornhub.com/view_video.php?viewkey=", "").replace("https://pt.pornhub.com/view_video.php?viewkey=", "");
            enviar = new VideoComposer("pornhub", VideoId);
        }
        /// Xvideos JSON
        else if (videolink.contains("xvideos.com")) {
            /// Obtem o ID do vídeo
            VideoId = videolink.replace("https://www.xvideos.com/video", "").replace("http://www.xvideos.com/video", "");
            String VideoXVID = VideoId.split("/")[0];
            enviar = new VideoComposer("xvideos", VideoXVID);
        }

        if(enviar != null){
            for (Habbo habbo : gameClient.getHabbo().getHabboInfo().getCurrentRoom().getHabbos()) {
                PHBWebSocket.sendWSForUser(enviar,habbo);
            }
        } else {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_roomvideo.error"));
        }
        return true;
    }
}