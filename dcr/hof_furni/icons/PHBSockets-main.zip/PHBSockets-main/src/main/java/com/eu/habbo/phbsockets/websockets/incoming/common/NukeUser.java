package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.rooms.RoomUnitEffect;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class NukeUser extends IncomingWebMessage<NukeUser.JSONExplodirCommand> {

    public NukeUser() {
        super(JSONExplodirCommand.class);
    }

    @Override
    public void handle(WebSocketClient gameClient, JSONExplodirCommand message) throws InterruptedException {

        Habbo habbo = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getHabbo(message.username);

        if (habbo != null) {

            /// Cooldown
            Integer timestamp = Emulator.getIntUnixTimestamp();
            Integer last_cmd = 0;
            // Verifica se usuário pode executar comando
            if(gameClient.getHabbo().getHabboStats().cache.contains("last_nuke")) {
                last_cmd = Integer.parseInt(gameClient.getHabbo().getHabboStats().cache.get("last_nuke").toString());
                Integer cooldown = Integer.parseInt(Emulator.getConfig().getValue("phbsockets.nuke.cooldown"));
                ///Bypass
                if (gameClient.getHabbo().getHabboInfo().getRank().getId() >= Integer.valueOf(Emulator.getConfig().getValue("phbsockets.rank.cooldown.bypass")))
                    last_cmd = 0;
                if (timestamp - last_cmd < cooldown) {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.cooldown.error").replace("%time%", String.valueOf(((last_cmd + cooldown) - timestamp))));
                    return;
                }
            }

            gameClient.getHabbo().getHabboStats().cache.put("last_nuke", timestamp);

            gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.nuke.action").replace("%username%", habbo.getHabboInfo().getUsername()));

            Emulator.getThreading().run(() -> {
                gameClient.getHabbo().getHabboInfo().getCurrentRoom().giveEffect(habbo, RoomUnitEffect.NINJADISAPPEAR.getId(), 10);
                habbo.shout(Emulator.getTexts().getValue("commands.text.nuke.nuked").replace("%username%", habbo.getHabboInfo().getUsername()));
            }, 500);

            return;
        }
    }

    static class JSONExplodirCommand {
        String username;
    }
}
