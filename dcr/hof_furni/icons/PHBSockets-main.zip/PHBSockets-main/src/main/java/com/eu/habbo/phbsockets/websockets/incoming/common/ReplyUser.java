package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.WebSocketManager;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;
import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.eu.habbo.phbsockets.websockets.outgoing.common.MentionComposer;

public class ReplyUser extends IncomingWebMessage<ReplyUser.JSONResponderUser> {

    public ReplyUser() {
        super(JSONResponderUser.class);
    }

    @Override
    public void handle(WebSocketClient client, JSONResponderUser message) {

        OutgoingWebMessage enviar = new MentionComposer("@"+message.username+" "+message.text, client.getHabbo().getHabboInfo().getUsername(), client.getHabbo().getHabboInfo().getId(), client.getHabbo().getHabboInfo().getLook(), client.getHabbo().getRoomUnit().getId());

        Habbo habbo = Emulator.getGameEnvironment().getHabboManager().getHabbo(message.username);

        if (habbo == null || !habbo.isOnline()) {
            client.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.mention.invaliduser"));
        } else if (habbo.getHabboInfo().getId() == client.getHabbo().getHabboInfo().getId()) {
            client.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.mention.needy"));
        } else {
            WebSocketClient wsClient = WebSocketManager.getInstance().getClientManager().getWebSocketClientForHabbo(habbo.getHabboInfo().getId());
            if(wsClient != null) {
                client.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.mention.replied").replace("%username%", habbo.getHabboInfo().getUsername()));
                wsClient.sendMessage(enviar);
            }
        }

    }

    static class JSONResponderUser {
        String username;
        String text;
    }
}
