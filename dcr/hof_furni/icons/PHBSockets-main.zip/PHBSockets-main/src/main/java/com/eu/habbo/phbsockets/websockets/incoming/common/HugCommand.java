package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.rooms.RoomChatMessageBubbles;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class HugCommand extends IncomingWebMessage<HugCommand.JSONAbracarCommand> {

    public HugCommand() {
        super(JSONAbracarCommand.class);
    }

    @Override
    public void handle(WebSocketClient gameClient, JSONAbracarCommand message) throws InterruptedException {

        Habbo habbo = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getHabbo(message.username);
        final Room room = gameClient.getHabbo().getHabboInfo().getCurrentRoom();

        if (habbo != null) {

            /// Cooldown
            Integer timestamp = Emulator.getIntUnixTimestamp();
            Integer last_cmd = 0;
            // Verifica se usuário pode executar comando
            if(gameClient.getHabbo().getHabboStats().cache.contains("last_hug")) {
                last_cmd = Integer.parseInt(gameClient.getHabbo().getHabboStats().cache.get("last_hug").toString());
                Integer cooldown = Integer.parseInt(Emulator.getConfig().getValue("phbsockets.hug.cooldown"));
                ///Bypass
                if (gameClient.getHabbo().getHabboInfo().getRank().getId() >= Integer.valueOf(Emulator.getConfig().getValue("phbsockets.rank.cooldown.bypass")))
                    last_cmd = 0;
                if (timestamp - last_cmd < cooldown) {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.cooldown.error").replace("%time%", String.valueOf(((last_cmd + cooldown) - timestamp))));
                    return;
                }
            }

            gameClient.getHabbo().getHabboStats().cache.put("last_hug", timestamp);

            if (habbo != gameClient.getHabbo()) {
                if (habbo.getRoomUnit().getCurrentLocation().distance(gameClient.getHabbo().getRoomUnit().getCurrentLocation()) <= 1.5) {

                    habbo.getRoomUnit().lookAtPoint(gameClient.getHabbo().getRoomUnit().getCurrentLocation());
                    gameClient.getHabbo().getRoomUnit().lookAtPoint(habbo.getRoomUnit().getCurrentLocation());
                    String[] HugEnable = Emulator.getConfig().getValue("phbsockets.hug.enable").split(";");
                    if (HugEnable.length > 0) {
                        room.giveEffect(gameClient.getHabbo(), Integer.valueOf(HugEnable[Emulator.getRandom().nextInt(HugEnable.length)]), 10);
                        room.giveEffect(habbo, Integer.valueOf(HugEnable[Emulator.getRandom().nextInt(HugEnable.length)]), 10);

                    }
                    gameClient.getHabbo().talk(Emulator.getTexts().getValue("commands.text.cmd_hug.hugger").replace("%hugger%", gameClient.getHabbo().getHabboInfo().getUsername()).replace("%huggedperson%", habbo.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);
                    habbo.talk(Emulator.getTexts().getValue("commands.text.cmd_hug.huggedperson").replace("%hugger%", gameClient.getHabbo().getHabboInfo().getUsername()).replace("%huggedperson%", habbo.getHabboInfo().getUsername()), RoomChatMessageBubbles.HEARTS);

                }
                else {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_hug.tofar").replace("%huggedperson%", habbo.getHabboInfo().getUsername()));
                }
            }
        }
    }

    static class JSONAbracarCommand {
        String username;
    }
}
