package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class PongEvent extends IncomingWebMessage<PongEvent.JSONPongEvent> {

    public PongEvent() {
        super(JSONPongEvent.class);
    }

    @Override
    public void handle(WebSocketClient client, JSONPongEvent message) {
        //client.sendMessage(new PingComposer(message.message));
    }

    static class JSONPongEvent {
        String message;
    }
}
