package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.common.YoutubeMusicComposer;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Scanner;

public class RoomYoutubeMusicSocketCommand extends Command {
    public RoomYoutubeMusicSocketCommand(String permission, String[] keys) {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] strings) throws Exception {
        final Room room = gameClient.getHabbo().getHabboInfo().getCurrentRoom();
        if(Emulator.getConfig().getValue("phbsockets.youtube.apikey").length() < 5){
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.youtube.api.config"));
            return true;
        }
        if (strings.length < 2) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.texts.cmd_youtube.error"));
            return true;
        }
        if(!room.hasRights(gameClient.getHabbo())) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_roomvideo.owner"));
            return true;
        }
        String VideoName = "";
        if (strings.length > 1) {
            StringBuilder message = new StringBuilder();
            for (int i = 1; i < strings.length; i++) {
                message.append(strings[i]).append(" ");
            }
            VideoName = URLEncoder.encode(message.toString(), "UTF-8");
        }
        HttpURLConnection con = null;
        try {
            URL url = new URL("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&q="+VideoName+"&regionCode=US&type=video&videoCategoryId=10&fields=items(id(channelId%2CvideoId)%2Csnippet(channelId%2CchannelTitle%2Cdescription%2Ctitle))%2CnextPageToken%2CpageInfo%2CprevPageToken%2CregionCode&key="+Emulator.getConfig().getValue("phbplugin.cmd_youtube.apikey")+"&type=video&videoSyndicated=true");
            con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            InputStream inStream = con.getInputStream();
            String jsonObtido = new Scanner(inStream, "UTF-8").useDelimiter("\\Z").next();
            JsonObject jsonObject = new Gson().fromJson(jsonObtido, JsonObject.class);
            if(jsonObject.getAsJsonArray("items").get(0).getAsJsonObject().get("id").getAsJsonObject().get("videoId") == null){
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.youtube.api.error"));
            } else {
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_youtubemusic.success").replace("%title%", jsonObject.getAsJsonArray("items").get(0).getAsJsonObject().get("snippet").getAsJsonObject().get("title").toString()));
                for (Habbo habbo : gameClient.getHabbo().getHabboInfo().getCurrentRoom().getHabbos()) {
                    PHBWebSocket.sendWSForUser(new YoutubeMusicComposer(jsonObject.getAsJsonArray("items").get(0).getAsJsonObject().get("snippet").getAsJsonObject().get("title").toString().replace("\"", ""), jsonObject.getAsJsonArray("items").get(0).getAsJsonObject().get("id").getAsJsonObject().get("videoId").toString().replace("\"", "")), habbo);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.youtube.api.error"));
            return true;
        } finally {
            if (con != null)
                con.disconnect();
            return true;
        }
    }
}