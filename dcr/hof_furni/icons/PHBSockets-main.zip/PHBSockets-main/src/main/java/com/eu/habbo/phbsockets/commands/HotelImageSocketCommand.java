package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.common.ImageComposer;

public class HotelImageSocketCommand extends Command {
    public HotelImageSocketCommand(String permission, String[] keys) {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] strings) throws Exception {
        if (strings.length < 2) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_roomimage.url"));
            return false;
        }
        if (!strings[1].contains(".png") && !strings[1].contains(".jpg") && !strings[1].contains(".gif")) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_roomimage.url"));
            return false;
        }
        String imageLink = strings[1].replace("http://", "https://").replaceAll("\\<.*?\\>", "").replace("document.", "").replace("\"", "").replace("'", "");
        PHBWebSocket.sendWSForAll(new ImageComposer(imageLink));
        return true;
    }
}


