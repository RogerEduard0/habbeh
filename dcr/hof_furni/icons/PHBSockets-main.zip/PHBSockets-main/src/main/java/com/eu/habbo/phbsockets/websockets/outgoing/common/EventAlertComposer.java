package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class EventAlertComposer extends OutgoingWebMessage {

    public EventAlertComposer(String roomName, String userName, Integer userId, String userLook, Integer roomId) {
        super("event_alert");
        this.data.add("room_name", new JsonPrimitive(roomName));
        this.data.add("room_id", new JsonPrimitive(roomId));
        this.data.add("username", new JsonPrimitive(userName));
        this.data.add("userid", new JsonPrimitive(userId));
        this.data.add("userlook", new JsonPrimitive(userLook));
    }
}