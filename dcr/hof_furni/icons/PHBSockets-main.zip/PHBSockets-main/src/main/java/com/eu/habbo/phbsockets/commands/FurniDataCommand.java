package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.phbsockets.Main;
import com.eu.habbo.plugin.EventListener;

public class FurniDataCommand extends Command implements EventListener
{
    public FurniDataCommand(final String permission, final String[] keys) {
        super(permission, keys);
        Emulator.getPluginManager().registerEvents(Main.INSTANCE, this);
    }

    public boolean handle(final GameClient gameClient, final String[] strings) throws Exception {
        if (gameClient.getHabbo().getHabboStats().cache.containsKey("furnidata_cmd")) {
            gameClient.getHabbo().getHabboStats().cache.remove("furnidata_cmd");
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.cmd_furnidata.off"));
        }
        else {
            gameClient.getHabbo().getHabboStats().cache.put("furnidata_cmd", true);
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.cmd_furnidata.on"));
        }
        return true;
    }

}
