package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.messages.outgoing.rooms.RoomRelativeMapComposer;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class EditItemCommand extends IncomingWebMessage<EditItemCommand.JSONObtido> {

    public EditItemCommand() {
        super(JSONObtido.class);
    }

    @Override
    public void handle(WebSocketClient client, JSONObtido message) {

/*
        System.out.println(message.sprite_id);
        System.out.println(message.public_name);
        System.out.println(message.item_name);
        System.out.println(message.type);
        System.out.println(message.width);
        System.out.println(message.length);
        System.out.println(message.stack_height);
        System.out.println(message.allow_stack);
        System.out.println(message.allow_sit);
        System.out.println(message.allow_lay);
        System.out.println(message.allow_walk);
        System.out.println(message.allow_gift);
        System.out.println(message.allow_trade);
        System.out.println(message.allow_recycle);
        System.out.println(message.allow_marketplace_sell);
        System.out.println(message.allow_inventory_stack);
        System.out.println(message.interaction_type);
        System.out.println(message.interaction_modes_count);
        System.out.println(message.vending_ids);
        System.out.println(message.multiheight);
        System.out.println(message.customparams);
        System.out.println(message.effect_id_male);
        System.out.println(message.effect_id_female);
        System.out.println(message.clothing_on_walk);
        System.out.println(message.id);
*/

        try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
             PreparedStatement pstmt = connection.prepareStatement("UPDATE items_base SET sprite_id = ?, public_name = ?, item_name = ?, type = ?, width = ?, length = ?, stack_height = ?, allow_stack = ?, allow_sit = ?, allow_lay = ?, allow_walk= ?, allow_gift= ?, allow_trade= ?, allow_recycle= ?, allow_marketplace_sell= ?, allow_inventory_stack= ?, interaction_type= ?, interaction_modes_count= ?, vending_ids= ?, multiheight= ?, customparams= ?, effect_id_male= ?, effect_id_female= ?, clothing_on_walk= ? WHERE  id= ?;", Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, message.sprite_id);
            pstmt.setString(2, message.public_name);
            pstmt.setString(3, message.item_name);
            pstmt.setString(4, message.type);
            pstmt.setInt(5, message.width);
            pstmt.setInt(6, message.length);
            pstmt.setDouble(7, message.stack_height);
            pstmt.setInt(8, message.allow_stack);
            pstmt.setInt(9, message.allow_sit);
            pstmt.setInt(10, message.allow_lay);
            pstmt.setInt(11, message.allow_walk);
            pstmt.setInt(12, message.allow_gift);
            pstmt.setInt(13, message.allow_trade);
            pstmt.setInt(14, message.allow_recycle);
            pstmt.setInt(15, message.allow_marketplace_sell);
            pstmt.setInt(16, message.allow_inventory_stack);
            pstmt.setString(17, message.interaction_type);
            pstmt.setInt(18, message.interaction_modes_count);
            pstmt.setString(19, message.vending_ids);
            pstmt.setString(20, message.multiheight);
            pstmt.setString(21, message.customparams);
            pstmt.setInt(22, message.effect_id_male);
            pstmt.setInt(23, message.effect_id_female);
            pstmt.setString(24, message.clothing_on_walk);
            pstmt.setInt(25, message.id);
            pstmt.execute();
        } catch (SQLException e) {
            Emulator.getLogging().logSQLException(e);
            System.out.println(e);
            client.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_edititem.error").replace("%id%", message.id.toString()));
            return;
        }

        Emulator.getGameEnvironment().getItemManager().loadItems();
        Emulator.getGameEnvironment().getItemManager().loadCrackable();
        Emulator.getGameEnvironment().getItemManager().loadSoundTracks();

        synchronized (Emulator.getGameEnvironment().getRoomManager().getActiveRooms()) {
            for (Room room : Emulator.getGameEnvironment().getRoomManager().getActiveRooms()) {
                if (room.isLoaded() && room.getUserCount() > 0 && room.getLayout() != null) {
                    room.sendComposer(new RoomRelativeMapComposer(room).compose());
                }
            }
        }
        client.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_edititem.success.ws").replace("%id%", message.id.toString()));
        return;
    }

    static class JSONObtido {
        Integer id;
        Integer sprite_id;
        String public_name;
        String item_name;
        String type;
        Integer width;
        Integer length;
        Double stack_height;
        Integer allow_stack;
        Integer allow_sit;
        Integer allow_lay;
        Integer allow_walk;
        Integer allow_gift;
        Integer allow_trade;
        Integer allow_recycle;
        Integer allow_marketplace_sell;
        Integer allow_inventory_stack;
        String interaction_type;
        Integer interaction_modes_count;
        String vending_ids;
        String multiheight;
        String customparams;
        Integer effect_id_male;
        Integer effect_id_female;
        String clothing_on_walk;
    }
}
