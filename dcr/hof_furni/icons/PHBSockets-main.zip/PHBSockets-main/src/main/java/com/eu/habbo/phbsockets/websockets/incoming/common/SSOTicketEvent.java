package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.phbsockets.websockets.WebSocketManager;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;
import com.eu.habbo.phbsockets.websockets.outgoing.common.HelloWorldComposer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SSOTicketEvent extends IncomingWebMessage<SSOTicketEvent.JSONSSOTicketEvent> {

    public SSOTicketEvent() {
        super(JSONSSOTicketEvent.class);
    }
    private static final Logger LOGGER = LoggerFactory.getLogger(SSOTicketEvent.class);
    @Override
    public void handle(WebSocketClient client, JSONSSOTicketEvent message) {

        if(!client.tryAuthenticate(message.ticket)) {
            client.dispose();
            return;
        }

        LOGGER.info("[PHBSockets] - "+client.getHabbo().getHabboInfo().getUsername() + " connected to the WebSocket server.");

        /// Envia json welcome
        WebSocketClient wsClient = WebSocketManager.getInstance().getClientManager().getWebSocketClientForHabbo(client.getHabbo().getHabboInfo().getId());
        if(wsClient != null) {
            wsClient.sendMessage(new HelloWorldComposer(client.getHabbo()));
        }

    }

    static class JSONSSOTicketEvent {
        String ticket;
    }
}
