package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class UserClickEvent extends OutgoingWebMessage {
    public UserClickEvent(String userName, Integer userId, String userLook, String gender, boolean me) {
        super("userclick");
        this.data.add("username", new JsonPrimitive(userName));
        this.data.add("userid", new JsonPrimitive(userId));
        this.data.add("userlook", new JsonPrimitive(userLook));
        this.data.add("gender", new JsonPrimitive(gender));
        this.data.add("me", new JsonPrimitive(me));
    }
}