package com.eu.habbo.phbsockets.eventloader;

import com.eu.habbo.Emulator;
import com.eu.habbo.phbsockets.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class LoadPermissions {

    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    public static void checkDatabase() {
        LOGGER.info("[PHBSockets] - Loading Permissions...");
        boolean reloadPermissions = false;
        reloadPermissions = registerPermission("cmd_eventalert", "'0', '1', '2'", "0", reloadPermissions);
        reloadPermissions = registerPermission("cmd_roomvideo", "'0', '1', '2'", "1", reloadPermissions);
        reloadPermissions = registerPermission("cmd_hotelvideo", "'0', '1', '2'", "0", reloadPermissions);
        reloadPermissions = registerPermission("cmd_disablealertevent", "'0', '1', '2'", "1", reloadPermissions);
        reloadPermissions = registerPermission("cmd_furnidata", "'0', '1'", "0", reloadPermissions);
        reloadPermissions = registerPermission("cmd_hotelimage", "'0', '1'", "0", reloadPermissions);
        reloadPermissions = registerPermission("cmd_roomimage", "'0', '1'", "1", reloadPermissions);
        reloadPermissions = registerPermission("cmd_coloradd", "'0', '1'", "1", reloadPermissions);
        reloadPermissions = registerPermission("cmd_edititem", "'0', '1', '2'", "0", reloadPermissions);
        reloadPermissions = registerPermission("cmd_youtube", "'0', '1', '2'", "2", reloadPermissions);
        reloadPermissions = registerPermission("cmd_addvideo_youtubetv", "'0', '1'", "1", reloadPermissions);
        reloadPermissions = registerPermission("cmd_manage_youtubetv", "'0', '1'", "1", reloadPermissions);
        reloadPermissions = registerPermission("acc_mention_everyone", "'0', '1'", "0", reloadPermissions);
        reloadPermissions = registerPermission("acc_mention_staff", "'0', '1'", "0", reloadPermissions);
        reloadPermissions = registerPermission("acc_mention_room", "'0', '1'", "0", reloadPermissions);
        reloadPermissions = registerPermission("acc_mention_friends", "'0', '1'", "0", reloadPermissions);
        reloadPermissions = registerPermission("acc_mention_user", "'0', '1'", "1", reloadPermissions);
        reloadPermissions = registerPermission("cmd_youtubemusic", "'0', '1', '2'", "2", reloadPermissions);
        reloadPermissions = registerPermission("cmd_roomiframe", "'0', '1', '2'", "2", reloadPermissions);
        reloadPermissions = registerPermission("acc_override_sex", "'0', '1'", "0", reloadPermissions);
        reloadPermissions = registerPermission("cmd_disablesex", "'0', '1', '2'", "2", reloadPermissions);

        if (reloadPermissions) {
            Emulator.getGameEnvironment().getPermissionsManager().reload();
        }
    }

    private static boolean registerPermission(String name, String options, String defaultValue, boolean defaultReturn) {
        try (Connection connection = Emulator.getDatabase().getDataSource().getConnection()) {
            try (PreparedStatement statement = connection.prepareStatement("ALTER TABLE  `permissions` ADD  `" + name + "` ENUM(  " + options + " ) NOT NULL DEFAULT  '" + defaultValue + "'")) {
                statement.execute();
                return true;
            }
        } catch (SQLException e) {
        }
        return defaultReturn;
    }
}