package com.eu.habbo.phbsockets.interactiontypes;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.habbohotel.items.Item;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.habbohotel.rooms.RoomUnit;
import com.eu.habbo.habbohotel.users.HabboItem;
import com.eu.habbo.messages.ServerMessage;
import com.eu.habbo.phbsockets.Main;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.common.YoutubeTVComposer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InteractionAlternativeYoutubeTV extends HabboItem {

    private static final Logger LOGGER = LoggerFactory.getLogger(InteractionAlternativeYoutubeTV.class);
    public InteractionAlternativeYoutubeTV(ResultSet set, Item baseItem) throws SQLException {
        super(set, baseItem);
    }

    public InteractionAlternativeYoutubeTV(int id, int userId, Item item, String extradata, int limitedStack, int limitedSells) {
        super(id, userId, item, extradata, limitedStack, limitedSells);
    }

    @Override
    public boolean canWalkOn(RoomUnit roomUnit, Room room, Object[] objects) {
        return false;
    }

    @Override
    public boolean isWalkable() {
        return false;
    }

    @Override
    public void onWalk(RoomUnit roomUnit, Room room, Object[] objects) throws Exception {
    }

    @Override
    public void onClick(GameClient client, Room room, Object[] objects) throws Exception {
        super.onClick(client, room, objects);
        String videoData = "";
        try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT JSON_OBJECT('phbplugin_video_data', JSON_ARRAYAGG(JSON_OBJECT('video_id', video_id, 'video_title', video_title, 'video_channel', video_channel))) AS json from phbplugin_youtubetv WHERE user_id = ? ORDER BY id DESC;")) {
            statement.setInt(1, this.getUserId());
            try (ResultSet set = statement.executeQuery()) {
                if (set.next()) {
                    videoData = set.getString("json");
                    PHBWebSocket.sendWSForUser(new YoutubeTVComposer(this.getId(), videoData), client.getHabbo());
                } else {
                    client.getHabbo().whisper("Youtube TV Error!");
                    return;
                }
            }
        } catch (SQLException e) {
            LOGGER.error(e.getMessage());
        }
    }

    @Override
    public void serializeExtradata(ServerMessage serverMessage) {
        if (this.getExtradata().length() == 0)
            this.setExtradata("");
        serverMessage.appendInt(1 + (this.isLimited() ? 256 : 0));
        serverMessage.appendInt(2);
        serverMessage.appendString("THUMBNAIL_URL");
        if (this.getExtradata() == null) {
            serverMessage.appendString("");
        } else {
            serverMessage.appendString(Emulator.getConfig().getValue("imager.url.youtube").replace("%video%", this.getExtradata()));
        }
        serverMessage.appendString("videoId");
        serverMessage.appendString(this.getExtradata());
        super.serializeExtradata(serverMessage);
    }
}
