package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class ReplyMention extends IncomingWebMessage<ReplyMention.JSONResponderMencao> {

    public ReplyMention() {
        super(JSONResponderMencao.class);
    }

    @Override
    public void handle(WebSocketClient client, JSONResponderMencao message) {
        if (client.getHabbo() != null) {
            client.getHabbo().getHabboStats().cache.put("replymention", message.user);
            client.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.mention.reply").replace("%username%",  message.user));
        } else {
            client.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.mention.invaliduser").replace("%username%",  message.user));
        }
    }

    static class JSONResponderMencao {
        String user;
    }
}
