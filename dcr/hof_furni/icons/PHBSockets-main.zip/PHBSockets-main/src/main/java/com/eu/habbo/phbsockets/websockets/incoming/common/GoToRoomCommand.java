package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class GoToRoomCommand extends IncomingWebMessage<GoToRoomCommand.JSONIrQuarto> {

    public GoToRoomCommand() {
        super(JSONIrQuarto.class);
    }

    @Override
    public void handle(WebSocketClient client, JSONIrQuarto message) {
        Room room = Emulator.getGameEnvironment().getRoomManager().loadRoom(message.roomid);
        if(client.getHabbo().getHabboInfo().getCurrentRoom() != null) {
            if (client.getHabbo().getHabboInfo().getCurrentRoom().getId() == room.getId()) {
                client.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.followuser.error"));
                return;
            }
        }
        client.getHabbo().goToRoom(room.getId());
    }

    static class JSONIrQuarto {
        Integer roomid;
    }
}
