package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.habbohotel.rooms.RoomState;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.common.EventAlertComposer;

public class EventAlertSocketCommand extends Command
{
    public EventAlertSocketCommand(String permission, String[] keys)
    {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] params) throws Exception {

        String roomName = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getName();
        String user = gameClient.getHabbo().getHabboInfo().getUsername();
        Integer roomid = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getId();

        if (params.length > 1) {
            StringBuilder message = new StringBuilder();
            for (int i = 1; i < params.length; i++) {
                message.append(params[i]).append(" ");
            }
            roomName = message.toString();
        }

        if(Integer.valueOf(Emulator.getConfig().getValue("phbsockets.eventalert.openroom.enabled")) == 1) {
            gameClient.getHabbo().getHabboInfo().getCurrentRoom().setState(RoomState.OPEN);
        }

        PHBWebSocket.sendWSForAllEvent(new EventAlertComposer(roomName.replace("\"", "'"), user, gameClient.getHabbo().getHabboInfo().getId(), gameClient.getHabbo().getHabboInfo().getLook(), roomid), roomid);

        if(Integer.valueOf(Emulator.getConfig().getValue("phbsockets.eventalert.closeroom.enabled")) == 1) {
            Emulator.getThreading().run(() -> {
                gameClient.getHabbo().getHabboInfo().getCurrentRoom().setState(RoomState.LOCKED);
            }, Integer.valueOf(Emulator.getConfig().getValue("phbsockets.eventalert.closeroom.time")) * 1000);
        }
        return true;
    }

}