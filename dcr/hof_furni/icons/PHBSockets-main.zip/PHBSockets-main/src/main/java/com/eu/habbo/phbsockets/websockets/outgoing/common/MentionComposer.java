package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class MentionComposer extends OutgoingWebMessage {
    public MentionComposer(String message, String userName, Integer userId, String userLook, Integer roomId) {
        super("mention");
        this.data.add("message", new JsonPrimitive(message));
        this.data.add("username", new JsonPrimitive(userName));
        this.data.add("userid", new JsonPrimitive(userId));
        this.data.add("userlook", new JsonPrimitive(userLook));
        this.data.add("roomid", new JsonPrimitive(roomId));
    }
}