package com.eu.habbo.phbsockets.eventloader;

import com.eu.habbo.Emulator;
import com.eu.habbo.phbsockets.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class loadAll {

    private static final Logger LOGGER = LoggerFactory.getLogger(loadAll.class);

    public static void loadAll() throws Exception {

        LoadPlayerCommands.loadPlayerCommands();
        LoadConfig.loadConfig();

        if(Emulator.getConfig().getValue("phbplugin.install.language").equals("EN"))
            LoadTextsEN.loadTexts();
        else if(Emulator.getConfig().getValue("phbplugin.install.language").equals("PT"))
            LoadTextsPT.loadTexts();
        else
            LOGGER.error("[PHBSockets] - Invalid config phbcommands.install.language, set EN or PT to install texts.");

    }
}
