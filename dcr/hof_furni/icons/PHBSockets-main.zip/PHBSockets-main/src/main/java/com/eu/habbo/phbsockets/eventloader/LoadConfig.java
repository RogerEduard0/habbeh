package com.eu.habbo.phbsockets.eventloader;

import com.eu.habbo.Emulator;
import com.eu.habbo.phbsockets.Main;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoadConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    public static void loadConfig() {
        try {
            LOGGER.info("[PHBSockets] - Loading Settings...");
            Emulator.getConfig().register("phbsockets.coloradd.imgurl", "https://i.imgur.com/8XdXPZ8.png");
            Emulator.getConfig().register("phbsockets.eventalert.closeroom.time", "12");
            Emulator.getConfig().register("phbsockets.eventalert.openroom.enabled", "1");
            Emulator.getConfig().register("phbsockets.eventalert.closeroom.enabled", "1");
            Emulator.getConfig().register("phbsockets.host", "0.0.0.0");
            Emulator.getConfig().register("phbsockets.port", "8443");
            Emulator.getConfig().register("phbsockets.cert.pass", "");
            Emulator.getConfig().register("phbsockets.youtube.apikey", "");
            Emulator.getConfig().register("phbsockets.rank.cooldown.bypass", "7");
            Emulator.getConfig().register("phbsockets.sex.cooldown", "20");
            Emulator.getConfig().register("phbsockets.slime.cooldown", "10");
            Emulator.getConfig().register("phbsockets.nuke.cooldown", "10");
            Emulator.getConfig().register("phbsockets.push.cooldown", "5");
            Emulator.getConfig().register("phbsockets.pull.cooldown", "5");
            Emulator.getConfig().register("phbsockets.hug.cooldown", "5");
            Emulator.getConfig().register("phbsockets.sex.enable", "507");
            Emulator.getConfig().register("phbsockets.kiss.cooldown", "5");
            Emulator.getConfig().register("phbsockets.hug.enable", "10");
        } catch (Exception ex) {
           LOGGER.error(ex.getMessage());
        }
    }
}
