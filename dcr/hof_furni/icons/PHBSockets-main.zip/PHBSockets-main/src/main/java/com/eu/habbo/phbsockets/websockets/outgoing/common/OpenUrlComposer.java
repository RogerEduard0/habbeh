package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class OpenUrlComposer extends OutgoingWebMessage {
    public OpenUrlComposer(String url, String type) {
        super("url");
        this.data.add("url", new JsonPrimitive(url));
        this.data.add("type", new JsonPrimitive(type));
    }
}
