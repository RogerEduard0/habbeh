package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class HelloWorldComposer extends OutgoingWebMessage {
    public HelloWorldComposer(Habbo user) {
        super("helloworld");
        this.data.add("Powered By", new JsonPrimitive("PHB"));
        this.data.add("WhatsApp", new JsonPrimitive("+5521998149241"));
        this.data.add("Discord", new JsonPrimitive("PedroHB#9569"));
        this.data.add("Email", new JsonPrimitive("pedrohenrique12342@gmail.com"));
        this.data.add("Website", new JsonPrimitive("https://phb.services/"));
        this.data.add("username", new JsonPrimitive(user.getHabboInfo().getUsername()));
        this.data.add("rank", new JsonPrimitive(user.getHabboInfo().getRank().getId()));
        this.data.add("rank_effect", new JsonPrimitive(user.getHabboInfo().getRank().getRoomEffect()));
    }
}