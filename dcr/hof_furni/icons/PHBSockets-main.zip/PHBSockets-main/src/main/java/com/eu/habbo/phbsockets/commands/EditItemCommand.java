package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.habbohotel.items.Item;
import com.eu.habbo.habbohotel.rooms.Room;
import com.eu.habbo.messages.outgoing.rooms.RoomRelativeMapComposer;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.common.EditItemComposer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class EditItemCommand extends Command
{
    public EditItemCommand(String permission, String[] keys)
    {
        super(permission, keys);
    }

    @Override
    public boolean handle(GameClient gameClient, String[] strings) throws Exception {

        if (strings.length >= 4) {
            Integer itemid = Integer.valueOf(strings[1]);
            Item baseItem = Emulator.getGameEnvironment().getItemManager().getItem(itemid);

            if (baseItem == null) {
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_edititem.invalidfurni").replace("%id%", itemid.toString()));
                return true;
            } else {
                String sql = "";
                String parametro = strings[2];
                String valor = strings[3].replace("'", "").replace("\\", "");

                if(parametro.equals("width")){
                    sql = "UPDATE items_base SET width = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("length")){
                    sql = "UPDATE items_base SET length = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("stack_height")){
                    sql = "UPDATE items_base SET stack_height = '"+valor+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("allow_stack")){
                    if(!Integer.valueOf(valor).equals(1))
                        valor = "0";
                    sql = "UPDATE items_base SET allow_stack = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("allow_sit")){
                    if(!Integer.valueOf(valor).equals(1))
                        valor = "0";
                    sql = "UPDATE items_base SET allow_sit = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("allow_lay")){
                    if(!Integer.valueOf(valor).equals(1))
                        valor = "0";
                    sql = "UPDATE items_base SET allow_lay = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("allow_walk")){
                    if(!Integer.valueOf(valor).equals(1))
                        valor = "0";
                    sql = "UPDATE items_base SET allow_walk = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("allow_gift")){
                    if(!Integer.valueOf(valor).equals(1))
                        valor = "0";
                    sql = "UPDATE items_base SET allow_gift = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("allow_trade")){
                    if(!Integer.valueOf(valor).equals(1))
                        valor = "0";
                    sql = "UPDATE items_base SET allow_trade = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("allow_recycle")){
                    if(!Integer.valueOf(valor).equals(1))
                        valor = "0";
                    sql = "UPDATE items_base SET allow_recycle = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("allow_marketplace_sell")){
                    if(!Integer.valueOf(valor).equals(1))
                        valor = "0";
                    sql = "UPDATE items_base SET allow_marketplace_sell = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("allow_inventory_stack")){
                    if(!Integer.valueOf(valor).equals(1))
                        valor = "0";
                    sql = "UPDATE items_base SET allow_inventory_stack = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("interaction_type")){
                    sql = "UPDATE items_base SET interaction_type = '"+valor+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("interaction_modes_count")){
                    sql = "UPDATE items_base SET interaction_modes_count = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("vending_ids")){
                    sql = "UPDATE items_base SET vending_ids = '"+valor+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("multiheight")){
                    sql = "UPDATE items_base SET multiheight = '"+valor+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("customparams")){
                    sql = "UPDATE items_base SET customparams = '"+valor+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("effect_id_male")){
                    sql = "UPDATE items_base SET effect_id_male = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("effect_id_female")){
                    sql = "UPDATE items_base SET effect_id_female = '"+Integer.valueOf(valor)+"' WHERE id = '"+itemid+"';";
                } else if(parametro.equals("clothing_on_walk")){
                    sql = "UPDATE items_base SET clothing_on_walk = '"+valor+"' WHERE id = '"+itemid+"';";
                } else {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_edititem.invalidparam"));
                    return true;
                }

                /// Executa o SQL
                try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
                     PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                    pstmt.execute();
                } catch (SQLException e) {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_edititem.error"));
                    gameClient.getHabbo().whisper(e.getMessage());
                    return true;
                }

                /// UpdateItemsCommand
                Emulator.getGameEnvironment().getItemManager().loadItems();
                Emulator.getGameEnvironment().getItemManager().loadCrackable();
                Emulator.getGameEnvironment().getItemManager().loadSoundTracks();
                synchronized (Emulator.getGameEnvironment().getRoomManager().getActiveRooms()) {
                    for (Room room : Emulator.getGameEnvironment().getRoomManager().getActiveRooms()) {
                        if (room.isLoaded() && room.getUserCount() > 0 && room.getLayout() != null) {
                            room.sendComposer(new RoomRelativeMapComposer(room).compose());
                        }
                    }
                }
                //

                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_edititem.success").replace("%param%", parametro).replace("%id%", itemid.toString()).replace("%value%", valor));
                return true;
            }
        } else {
            if(strings.length == 2){
                Integer itemid = Integer.valueOf(strings[1]);
                Item baseItem = Emulator.getGameEnvironment().getItemManager().getItem(itemid);
                    if (baseItem == null) {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_edititem.invalidfurni").replace("%id%", itemid.toString()));
                    return true;
                 } else {
                        PHBWebSocket.sendWSForUser(new EditItemComposer(baseItem.getId()), gameClient.getHabbo());
                    return true;
                    }
                }
            if(!gameClient.getHabbo().getHabboStats().cache.containsKey("editaritem")) {
                gameClient.getHabbo().getHabboStats().cache.put("editaritem", true);
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_edititem.enabled"));
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_edititem.example2"));
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_editaritem.exemplo2"));
            } else {
                gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.text.cmd_edititem.example3"));
                gameClient.getHabbo().getHabboStats().cache.remove("editaritem");
            }
        }
        return true;
    }
}