package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.phbsockets.Main;
import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EditItemComposer extends OutgoingWebMessage {

    private static final Logger LOGGER = LoggerFactory.getLogger(EditItemComposer.class);

    public EditItemComposer(Integer id) {
        super("edit_item");
        try (Connection connection = Emulator.getDatabase().getDataSource().getConnection();
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM items_base WHERE id = ?")) {
            statement.setInt(1, id);
            try (ResultSet set = statement.executeQuery()) {
                if (set.next()) {
                    this.data.add("id", new JsonPrimitive(set.getInt("id")));
                    this.data.add("sprite_id", new JsonPrimitive(set.getInt("sprite_id")));
                    this.data.add("public_name", new JsonPrimitive(set.getString("public_name")));
                    this.data.add("item_name", new JsonPrimitive(set.getString("item_name")));
                    this.data.add("type", new JsonPrimitive(set.getString("type")));
                    this.data.add("width", new JsonPrimitive(set.getInt("width")));
                    this.data.add("length", new JsonPrimitive(set.getInt("length")));
                    this.data.add("stack_height", new JsonPrimitive(set.getDouble("stack_height")));
                    this.data.add("allow_stack", new JsonPrimitive(set.getInt("allow_stack")));
                    this.data.add("allow_sit", new JsonPrimitive(set.getInt("allow_sit")));
                    this.data.add("allow_lay", new JsonPrimitive(set.getInt("allow_lay")));
                    this.data.add("allow_walk", new JsonPrimitive(set.getInt("allow_walk")));
                    this.data.add("allow_gift", new JsonPrimitive(set.getInt("allow_gift")));
                    this.data.add("allow_trade", new JsonPrimitive(set.getInt("allow_trade")));
                    this.data.add("allow_recycle", new JsonPrimitive(set.getInt("allow_recycle")));
                    this.data.add("allow_marketplace_sell", new JsonPrimitive(set.getInt("allow_marketplace_sell")));
                    this.data.add("allow_inventory_stack", new JsonPrimitive(set.getInt("allow_inventory_stack")));
                    this.data.add("interaction_type", new JsonPrimitive(set.getString("interaction_type")));
                    this.data.add("interaction_modes_count", new JsonPrimitive(set.getInt("interaction_modes_count")));
                    this.data.add("vending_ids", new JsonPrimitive(set.getString("vending_ids")));
                    this.data.add("multiheight", new JsonPrimitive(set.getString("multiheight")));
                    this.data.add("customparams", new JsonPrimitive(set.getString("customparams")));
                    this.data.add("effect_id_male", new JsonPrimitive(set.getInt("effect_id_male")));
                    this.data.add("effect_id_female", new JsonPrimitive(set.getInt("effect_id_female")));
                    this.data.add("clothing_on_walk", new JsonPrimitive(set.getString("clothing_on_walk")));
                }
            }
        } catch (SQLException e) {
            LOGGER.error(e.getMessage());
        }
    }
}