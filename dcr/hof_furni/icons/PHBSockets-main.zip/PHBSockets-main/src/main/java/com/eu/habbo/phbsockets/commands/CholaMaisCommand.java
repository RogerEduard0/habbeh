package com.eu.habbo.phbsockets.commands;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.commands.Command;
import com.eu.habbo.habbohotel.gameclients.GameClient;
import com.eu.habbo.phbsockets.websockets.PHBWebSocket;
import com.eu.habbo.phbsockets.websockets.outgoing.common.VideoComposer;

public class CholaMaisCommand extends Command {
    public CholaMaisCommand() {
        super(null, "cholamais".split(";"));
    }

    @Override
    public boolean handle(GameClient gameClient, String[] params) throws Exception {
        String[] videosId = {"peA6xbaBMBk","sAVzp24d-w8", "iqhJWX72Y5U"};
        int randomIndex = (int)(Math.random()*videosId.length);
        String randomElement = videosId[randomIndex];
        PHBWebSocket.sendWSForUser(new VideoComposer("youtube", randomElement), gameClient.getHabbo());
        return true;
    }
}
