package com.eu.habbo.phbsockets.websockets.outgoing.common;

import com.eu.habbo.phbsockets.websockets.outgoing.OutgoingWebMessage;
import com.google.gson.JsonPrimitive;

public class SessionDataComposer extends OutgoingWebMessage {
    public SessionDataComposer(int id, String username, int credits, String look) {
        super("session_data");
        this.data.add("id", new JsonPrimitive(id));
        this.data.add("username", new JsonPrimitive(username));
        this.data.add("credits", new JsonPrimitive(credits));
        this.data.add("look", new JsonPrimitive(look));
    }
}
