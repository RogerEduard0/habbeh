package com.eu.habbo.phbsockets.websockets.incoming.common;

import com.eu.habbo.Emulator;
import com.eu.habbo.habbohotel.rooms.RoomChatMessage;
import com.eu.habbo.habbohotel.rooms.RoomChatMessageBubbles;
import com.eu.habbo.habbohotel.rooms.RoomTile;
import com.eu.habbo.habbohotel.users.Habbo;
import com.eu.habbo.habbohotel.users.HabboGender;
import com.eu.habbo.messages.outgoing.rooms.users.RoomUserTalkComposer;
import com.eu.habbo.phbsockets.websockets.clients.WebSocketClient;
import com.eu.habbo.phbsockets.websockets.incoming.IncomingWebMessage;

public class PushCommand extends IncomingWebMessage<PushCommand.JSONEmpurrarCommand> {

    public PushCommand() {
        super(JSONEmpurrarCommand.class);
    }

    @Override
    public void handle(WebSocketClient gameClient, JSONEmpurrarCommand message) throws InterruptedException {

        Habbo habbo = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getHabbo(message.username);

        if (habbo == null) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.error.cmd_push.not_found").replace("%user%", habbo.getHabboInfo().getUsername()), RoomChatMessageBubbles.ALERT);
            return;
        } else if (habbo == gameClient.getHabbo()) {
            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.error.cmd_push.push_self"), RoomChatMessageBubbles.ALERT);
            return;
        } else {


            /// Cooldown
            Integer timestamp = Emulator.getIntUnixTimestamp();
            Integer last_cmd = 0;
            // Verifica se usuário pode executar comando
            if(gameClient.getHabbo().getHabboStats().cache.contains("last_empurrar")) {
                last_cmd = Integer.parseInt(gameClient.getHabbo().getHabboStats().cache.get("last_empurrar").toString());
                Integer cooldown = Integer.parseInt(Emulator.getConfig().getValue("phbsockets.push.cooldown"));
                ///Bypass
                if (gameClient.getHabbo().getHabboInfo().getRank().getId() >= Integer.valueOf(Emulator.getConfig().getValue("phbsockets.rank.cooldown.bypass")))
                    last_cmd = 0;
                if (timestamp - last_cmd < cooldown) {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("phbsockets.cooldown.error").replace("%time%", String.valueOf(((last_cmd + cooldown) - timestamp))));
                    return;
                }
            }
            gameClient.getHabbo().getHabboStats().cache.put("last_empurrar", timestamp);

            RoomTile tFront = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getLayout().getTileInFront(gameClient.getHabbo().getRoomUnit().getCurrentLocation(), gameClient.getHabbo().getRoomUnit().getBodyRotation().getValue());

            if (tFront != null && tFront.isWalkable()) {
                if (tFront.x == habbo.getRoomUnit().getX() && tFront.y == habbo.getRoomUnit().getY()) {
                    RoomTile tFrontTarget = gameClient.getHabbo().getHabboInfo().getCurrentRoom().getLayout().getTileInFront(habbo.getRoomUnit().getCurrentLocation(), gameClient.getHabbo().getRoomUnit().getBodyRotation().getValue());

                    if (tFrontTarget != null && tFrontTarget.isWalkable()) {
                        if (gameClient.getHabbo().getHabboInfo().getCurrentRoom().getLayout().getDoorTile() == tFrontTarget) {
                            gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.error.cmd_push.invalid").replace("%username%", habbo.getHabboInfo().getUsername()));
                            return;
                        }
                        habbo.getRoomUnit().setGoalLocation(tFrontTarget);
                        gameClient.getHabbo().getHabboInfo().getCurrentRoom().sendComposer(new RoomUserTalkComposer(new RoomChatMessage(Emulator.getTexts().getValue("commands.succes.cmd_push.push").replace("%user%", habbo.getHabboInfo().getUsername()).replace("%gender_name%", (gameClient.getHabbo().getHabboInfo().getGender().equals(HabboGender.M) ? Emulator.getTexts().getValue("gender.him") : Emulator.getTexts().getValue("gender.her"))), gameClient.getHabbo(), gameClient.getHabbo(), RoomChatMessageBubbles.NORMAL)).compose());
                    }
                } else {
                    gameClient.getHabbo().whisper(Emulator.getTexts().getValue("commands.error.cmd_push.cant_reach").replace("%user%", habbo.getHabboInfo().getUsername()), RoomChatMessageBubbles.ALERT);
                    return;
                }
            }
        }
        return;
    }

    static class JSONEmpurrarCommand {
        String username;
    }
}
